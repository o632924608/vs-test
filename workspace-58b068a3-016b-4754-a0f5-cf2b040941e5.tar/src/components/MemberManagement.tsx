"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Users, 
  Upload, 
  Plus, 
  Search, 
  Filter,
  FileText,
  CheckCircle,
  XCircle,
  Clock
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Member {
  id: string
  role: string
  status: string
  joinedAt: string
  leftAt?: string
  reason?: string
  club: {
    id: string
    name: string
  }
  student: {
    id: string
    studentId: string
    name: string
    email: string
    major?: string
    grade?: string
  }
}

interface Club {
  id: string
  name: string
}

interface ImportResult {
  studentId: string
  name: string
  email: string
  status: 'VALID' | 'INVALID'
  errorMsg?: string
}

export default function MemberManagement() {
  const [members, setMembers] = useState<Member[]>([])
  const [clubs, setClubs] = useState<Club[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedClub, setSelectedClub] = useState<string>('all')
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false)
  const [importResults, setImportResults] = useState<ImportResult[]>([])
  const [importStep, setImportStep] = useState<'upload' | 'preview' | 'result'>('upload')
  const [newMember, setNewMember] = useState({
    studentId: '',
    role: 'MEMBER'
  })
  const { toast } = useToast()

  useEffect(() => {
    fetchMembers()
    fetchClubs()
  }, [searchTerm, selectedClub, selectedStatus])

  const fetchMembers = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (selectedClub && selectedClub !== 'all') params.append('clubId', selectedClub)
      if (selectedStatus && selectedStatus !== 'all') params.append('status', selectedStatus)
      
      const response = await fetch(`/api/members?${params.toString()}`)
      if (response.ok) {
        const data = await response.json()
        let filteredMembers = data.members
        
        if (searchTerm) {
          filteredMembers = filteredMembers.filter((member: Member) =>
            member.student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            member.student.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
            member.student.email?.toLowerCase().includes(searchTerm.toLowerCase())
          )
        }
        
        setMembers(filteredMembers)
      }
    } catch (error) {
      console.error('获取成员列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchClubs = async () => {
    try {
      const response = await fetch('/api/clubs')
      if (response.ok) {
        const data = await response.json()
        setClubs(data.clubs)
      }
    } catch (error) {
      console.error('获取社团列表失败:', error)
    }
  }

  const handleAddMember = async () => {
    try {
      const response = await fetch('/api/members', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newMember,
          clubId: selectedClub
        }),
      })

      if (response.ok) {
        setIsAddDialogOpen(false)
        setNewMember({ studentId: '', role: 'MEMBER' })
        fetchMembers()
        toast({
          title: "添加成功",
          description: "成员添加成功",
        })
      } else {
        const error = await response.json()
        toast({
          variant: "destructive",
          title: "添加失败",
          description: error.error || '添加失败，请检查输入信息',
        })
      }
    } catch (error) {
      console.error('添加成员失败:', error)
      toast({
        variant: "destructive",
        title: "添加失败",
        description: "网络错误，请稍后重试",
      })
    }
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    try {
      const text = await file.text()
      const lines = text.split('\n').filter(line => line.trim())
      
      // 解析CSV数据 (假设格式: 学号,姓名,邮箱)
      const members = lines.slice(1).map(line => {
        const [studentId, name, email] = line.split(',').map(item => item.trim())
        return { studentId, name, email }
      }).filter(member => member.studentId && member.name)

      if (members.length === 0) {
        toast({
          variant: "destructive",
          title: "文件格式错误",
          description: "文件格式错误或无有效数据",
        })
        return
      }

      // 预检查数据
      const response = await fetch('/api/members/import/check', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          clubId: selectedClub,
          members
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setImportResults(data.results)
        setImportStep('preview')
      } else {
        const error = await response.json()
        toast({
          variant: "destructive",
          title: "预检查失败",
          description: error.error || '预检查失败，请检查文件格式',
        })
      }
    } catch (error) {
      console.error('文件处理失败:', error)
      toast({
        variant: "destructive",
        title: "文件处理失败",
        description: "文件处理失败，请稍后重试",
      })
    }
  }

  const handleConfirmImport = async () => {
    const validMembers = importResults.filter(r => r.status === 'VALID')
    
    try {
      const response = await fetch('/api/members/import/save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          clubId: selectedClub,
          members: validMembers
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setImportStep('result')
        fetchMembers()
      } else {
        const error = await response.json()
        toast({
          variant: "destructive",
          title: "导入失败",
          description: error.error || '导入失败，请稍后重试',
        })
      }
    } catch (error) {
      console.error('导入失败:', error)
      toast({
        variant: "destructive",
        title: "导入失败",
        description: "网络错误，请稍后重试",
      })
    }
  }

  const getRoleBadge = (role: string) => {
    const roleMap = {
      'MEMBER': { label: '会员', variant: 'secondary' as const },
      'STAFF': { label: '干事', variant: 'default' as const },
      'MANAGER': { label: '社长', variant: 'destructive' as const }
    }
    return roleMap[role as keyof typeof roleMap] || { label: role, variant: 'secondary' as const }
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      'ACTIVE': { label: '在社', variant: 'default' as const },
      'INACTIVE': { label: '已退出', variant: 'outline' as const }
    }
    return statusMap[status as keyof typeof statusMap] || { label: status, variant: 'secondary' as const }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">成员管理</h2>
          <p className="text-muted-foreground">管理社团成员，支持批量导入和转社申请</p>
        </div>
        <div className="flex space-x-2">
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                添加成员
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>添加成员</DialogTitle>
                <DialogDescription>
                  输入学生学号添加为社团成员。
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="studentId">学生学号</Label>
                  <Input
                    id="studentId"
                    value={newMember.studentId}
                    onChange={(e) => setNewMember({ ...newMember, studentId: e.target.value })}
                    placeholder="请输入学生学号"
                  />
                </div>
                <div>
                  <Label htmlFor="role">角色</Label>
                  <Select value={newMember.role} onValueChange={(value) => setNewMember({ ...newMember, role: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MEMBER">会员</SelectItem>
                      <SelectItem value="STAFF">干事</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  取消
                </Button>
                <Button onClick={handleAddMember}>
                  添加
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                批量导入
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>批量导入成员</DialogTitle>
                <DialogDescription>
                  支持CSV文件导入，格式：学号,姓名,邮箱
                </DialogDescription>
              </DialogHeader>
              
              <Tabs value={importStep} className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="upload">上传文件</TabsTrigger>
                  <TabsTrigger value="preview" disabled={importStep === 'upload'}>
                    预览数据
                  </TabsTrigger>
                  <TabsTrigger value="result" disabled={importStep !== 'result'}>
                    导入结果
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="upload" className="space-y-4">
                  <div>
                    <Label htmlFor="file">选择CSV文件</Label>
                    <Input
                      id="file"
                      type="file"
                      accept=".csv"
                      onChange={handleFileUpload}
                      className="mt-2"
                    />
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <p>文件格式要求：</p>
                    <ul className="list-disc list-inside mt-1">
                      <li>第一行为标题行（学号,姓名,邮箱）</li>
                      <li>每行一个成员信息</li>
                      <li>使用逗号分隔各字段</li>
                    </ul>
                  </div>
                </TabsContent>
                
                <TabsContent value="preview" className="space-y-4">
                  <div className="text-sm">
                    <span className="text-green-600">有效数据：{importResults.filter(r => r.status === 'VALID').length} 条</span>
                    <span className="text-red-600 ml-4">无效数据：{importResults.filter(r => r.status === 'INVALID').length} 条</span>
                  </div>
                  
                  <div className="max-h-96 overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>学号</TableHead>
                          <TableHead>姓名</TableHead>
                          <TableHead>邮箱</TableHead>
                          <TableHead>状态</TableHead>
                          <TableHead>备注</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {importResults.map((result, index) => (
                          <TableRow key={index}>
                            <TableCell>{result.studentId}</TableCell>
                            <TableCell>{result.name}</TableCell>
                            <TableCell>{result.email}</TableCell>
                            <TableCell>
                              {result.status === 'VALID' ? (
                                <Badge variant="default" className="bg-green-100 text-green-800">
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  有效
                                </Badge>
                              ) : (
                                <Badge variant="destructive">
                                  <XCircle className="h-3 w-3 mr-1" />
                                  无效
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-sm text-red-600">
                              {result.errorMsg}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setImportStep('upload')}>
                      返回
                    </Button>
                    <Button 
                      onClick={handleConfirmImport}
                      disabled={importResults.filter(r => r.status === 'VALID').length === 0}
                    >
                      确认导入
                    </Button>
                  </DialogFooter>
                </TabsContent>
                
                <TabsContent value="result" className="space-y-4">
                  <div className="text-center py-8">
                    <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                    <h3 className="text-lg font-medium">导入成功</h3>
                    <p className="text-sm text-muted-foreground mt-2">
                      成功导入 {importResults.filter(r => r.status === 'VALID').length} 名成员
                    </p>
                  </div>
                  
                  <DialogFooter>
                    <Button onClick={() => {
                      setIsImportDialogOpen(false)
                      setImportStep('upload')
                      setImportResults([])
                    }}>
                      完成
                    </Button>
                  </DialogFooter>
                </TabsContent>
              </Tabs>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* 筛选器 */}
      <Card>
        <CardHeader>
          <CardTitle>筛选条件</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="search">搜索</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="搜索姓名、学号或邮箱"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="club">社团</Label>
              <Select value={selectedClub} onValueChange={setSelectedClub}>
                <SelectTrigger>
                  <SelectValue placeholder="选择社团" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部社团</SelectItem>
                  {clubs.map((club) => (
                    <SelectItem key={club.id} value={club.id}>
                      {club.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="status">状态</Label>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="选择状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="ACTIVE">在社</SelectItem>
                  <SelectItem value="INACTIVE">已退出</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button variant="outline" onClick={() => {
                setSearchTerm('')
                setSelectedClub('all')
                setSelectedStatus('all')
              }}>
                <Filter className="h-4 w-4 mr-2" />
                重置筛选
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 成员列表 */}
      <Card>
        <CardHeader>
          <CardTitle>成员列表</CardTitle>
          <CardDescription>共找到 {members.length} 名成员</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="animate-pulse space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>学生信息</TableHead>
                  <TableHead>所属社团</TableHead>
                  <TableHead>角色</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead>加入时间</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {members.map((member) => (
                  <TableRow key={member.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{member.student.name}</div>
                        <div className="text-sm text-muted-foreground">{member.student.studentId}</div>
                        <div className="text-sm text-muted-foreground">{member.student.email}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{member.club.name}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getRoleBadge(member.role).variant}>
                        {getRoleBadge(member.role).label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadge(member.status).variant}>
                        {getStatusBadge(member.status).label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(member.joinedAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          转社申请
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}