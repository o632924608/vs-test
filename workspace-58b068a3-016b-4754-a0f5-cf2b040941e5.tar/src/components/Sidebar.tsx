"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Badge } from '@/components/ui/badge'
import { 
  LayoutDashboard,
  Building,
  Users,
  Calendar,
  CreditCard,
  FileText,
  Settings,
  Menu,
  Plus,
  Upload,
  UserPlus,
  LogOut
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface MenuItem {
  id: string
  label: string
  icon: React.ReactNode
  badge?: string
}

interface SidebarProps {
  currentPath: string
  onNavigate: (path: string) => void
  userRole: 'ADMIN' | 'CLUB_MANAGER' | 'STAFF' | 'STUDENT'
  userName: string
  onLogout: () => void
}

const menuItems: Record<string, MenuItem[]> = {
  ADMIN: [
    {
      id: 'dashboard',
      label: '系统概览',
      icon: <LayoutDashboard className="h-4 w-4" />
    },
    {
      id: 'clubs',
      label: '社团管理',
      icon: <Building className="h-4 w-4" />
    },
    {
      id: 'categories',
      label: '分类管理',
      icon: <Settings className="h-4 w-4" />
    },
    {
      id: 'members',
      label: '成员管理',
      icon: <Users className="h-4 w-4" />,
      badge: '3'
    },
    {
      id: 'transfers',
      label: '转社申请',
      icon: <Upload className="h-4 w-4" />,
      badge: '1'
    },
    {
      id: 'activities',
      label: '活动管理',
      icon: <Calendar className="h-4 w-4" />,
      badge: '2'
    },
    {
      id: 'finance',
      label: '财务管理',
      icon: <CreditCard className="h-4 w-4" />
    },
    {
      id: 'resources',
      label: '物资管理',
      icon: <FileText className="h-4 w-4" />,
      badge: '1'
    }
  ],
  CLUB_MANAGER: [
    {
      id: 'dashboard',
      label: '社团概览',
      icon: <LayoutDashboard className="h-4 w-4" />
    },
    {
      id: 'members',
      label: '成员管理',
      icon: <Users className="h-4 w-4" />,
      badge: '3'
    },
    {
      id: 'transfers',
      label: '转社申请',
      icon: <Upload className="h-4 w-4" />,
      badge: '1'
    },
    {
      id: 'activities',
      label: '活动管理',
      icon: <Calendar className="h-4 w-4" />
    },
    {
      id: 'finance',
      label: '财务管理',
      icon: <CreditCard className="h-4 w-4" />
    },
    {
      id: 'resources',
      label: '物资申请',
      icon: <FileText className="h-4 w-4" />
    }
  ],
  STAFF: [
    {
      id: 'dashboard',
      label: '工作台',
      icon: <LayoutDashboard className="h-4 w-4" />
    },
    {
      id: 'members',
      label: '成员审核',
      icon: <UserPlus className="h-4 w-4" />,
      badge: '3'
    },
    {
      id: 'transfers',
      label: '转社审批',
      icon: <Upload className="h-4 w-4" />,
      badge: '1'
    },
    {
      id: 'activities',
      label: '活动申请',
      icon: <Plus className="h-4 w-4" />
    },
    {
      id: 'resources',
      label: '物资申请',
      icon: <FileText className="h-4 w-4" />
    }
  ],
  STUDENT: [
    {
      id: 'dashboard',
      label: '我的社团',
      icon: <LayoutDashboard className="h-4 w-4" />
    },
    {
      id: 'activities',
      label: '活动报名',
      icon: <Calendar className="h-4 w-4" />
    },
    {
      id: 'transfer',
      label: '转社申请',
      icon: <Upload className="h-4 w-4" />
    }
  ]
}

export default function Sidebar({ currentPath, onNavigate, userRole, userName, onLogout }: SidebarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const items = menuItems[userRole] || []

  const getRoleLabel = (role: string) => {
    const roleMap = {
      'ADMIN': '超级管理员',
      'CLUB_MANAGER': '社团社长',
      'STAFF': '社团干事',
      'STUDENT': '普通学生'
    }
    return roleMap[role as keyof typeof roleMap] || role
  }

  const getRoleBadgeVariant = (role: string) => {
    const variantMap = {
      'ADMIN': 'default',
      'CLUB_MANAGER': 'secondary',
      'STAFF': 'outline',
      'STUDENT': 'secondary'
    }
    return variantMap[role as keyof typeof variantMap] || 'secondary'
  }

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden border-r bg-muted/40 md:block">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
            <div className="flex items-center gap-2 font-semibold">
              <span className="">社团管理系统</span>
            </div>
          </div>
          
          <div className="flex-1">
            <nav className="grid items-start px-2 text-sm font-medium lg:px-4">
              {items.map((item) => (
                <Button
                  key={item.id}
                  variant={currentPath === item.id ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-2",
                    currentPath === item.id && "bg-muted"
                  )}
                  onClick={() => onNavigate(item.id)}
                >
                  {item.icon}
                  {item.label}
                  {item.badge && (
                    <Badge variant="secondary" className="ml-auto">
                      {item.badge}
                    </Badge>
                  )}
                </Button>
              ))}
            </nav>
          </div>

          <div className="mt-auto p-4 border-t">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex-1">
                <p className="text-sm font-medium">{userName}</p>
                <Badge variant={getRoleBadgeVariant(userRole) as any} className="text-xs">
                  {getRoleLabel(userRole)}
                </Badge>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={onLogout}
            >
              <LogOut className="h-4 w-4 mr-2" />
              退出登录
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="shrink-0 md:hidden"
          >
            <Menu className="h-5 w-5" />
            <span className="sr-only">切换导航菜单</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="flex flex-col p-0">
          <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
            <div className="flex items-center gap-2 font-semibold">
              <span className="">社团管理系统</span>
            </div>
          </div>
          
          <div className="flex-1">
            <nav className="grid items-start px-2 text-sm font-medium lg:px-4">
              {items.map((item) => (
                <Button
                  key={item.id}
                  variant={currentPath === item.id ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-2",
                    currentPath === item.id && "bg-muted"
                  )}
                  onClick={() => {
                    onNavigate(item.id)
                    setIsMobileMenuOpen(false)
                  }}
                >
                  {item.icon}
                  {item.label}
                  {item.badge && (
                    <Badge variant="secondary" className="ml-auto">
                      {item.badge}
                    </Badge>
                  )}
                </Button>
              ))}
            </nav>
          </div>

          <div className="mt-auto p-4 border-t">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex-1">
                <p className="text-sm font-medium">{userName}</p>
                <Badge variant={getRoleBadgeVariant(userRole) as any} className="text-xs">
                  {getRoleLabel(userRole)}
                </Badge>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={onLogout}
            >
              <LogOut className="h-4 w-4 mr-2" />
              退出登录
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}