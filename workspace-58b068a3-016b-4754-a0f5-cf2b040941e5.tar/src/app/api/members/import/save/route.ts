import { NextResponse } from "next/server"
import { db } from '@/lib/db'

// POST - 保存批量导入的成员
export async function POST(request: Request) {
  try {
    const data = await request.json()
    const { clubId, members } = data

    if (!clubId || !members || !Array.isArray(members)) {
      return NextResponse.json(
        { error: '参数错误' },
        { status: 400 }
      )
    }

    // 使用事务批量插入
    const result = await db.$transaction(async (tx) => {
      const createdMembers = []

      for (const member of members) {
        if (member.status !== 'VALID') {
          continue
        }

        const createdMember = await tx.clubMember.create({
          data: {
            clubId,
            studentId: member.studentId,
            role: member.role || 'MEMBER',
            status: 'ACTIVE'
          },
          include: {
            club: {
              select: {
                id: true,
                name: true
              }
            },
            student: {
              select: {
                id: true,
                studentId: true,
                name: true,
                email: true,
                major: true,
                grade: true
              }
            }
          }
        })

        createdMembers.push(createdMember)
      }

      return createdMembers
    })

    return NextResponse.json({
      message: '导入成功',
      count: result.length,
      members: result
    })
  } catch (error) {
    console.error('保存导入成员失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}