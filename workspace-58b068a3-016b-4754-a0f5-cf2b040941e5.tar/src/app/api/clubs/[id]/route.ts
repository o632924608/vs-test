import { NextRequest, NextResponse } from "next/server"
import { db } from '@/lib/db'

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const clubId = params.id
    
    if (!clubId) {
      return NextResponse.json(
        { error: '社团ID不能为空' },
        { status: 400 }
      )
    }

    const data = await request.json()
    const { name, description, categoryId, status } = data

    // 验证社团是否存在
    const existingClub = await db.club.findUnique({
      where: { id: clubId }
    })

    if (!existingClub) {
      return NextResponse.json(
        { error: '社团不存在' },
        { status: 404 }
      )
    }

    // 如果修改了名称，检查是否与其他社团重复
    if (name && name !== existingClub.name) {
      const duplicateClub = await db.club.findFirst({
        where: { 
          name,
          id: { not: clubId }
        }
      })

      if (duplicateClub) {
        return NextResponse.json(
          { error: '社团名称已存在' },
          { status: 400 }
        )
      }
    }

    // 更新社团信息
    const updatedClub = await db.club.update({
      where: { id: clubId },
      data: {
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(categoryId && { categoryId }),
        ...(status && { status })
      },
      include: {
        category: true,
        manager: {
          select: {
            id: true,
            name: true,
            studentId: true
          }
        }
      }
    })

    return NextResponse.json({
      message: '社团信息更新成功',
      club: updatedClub
    })
  } catch (error) {
    console.error('更新社团失败:', error)
    return NextResponse.json(
      { error: '更新社团失败' },
      { status: 500 }
    )
  }
}