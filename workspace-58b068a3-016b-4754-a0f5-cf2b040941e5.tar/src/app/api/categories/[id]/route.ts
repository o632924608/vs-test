import { NextResponse } from "next/server"
import { db } from '@/lib/db'

// PUT - 更新分类
export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const data = await request.json()
    const { name, description, sort } = data

    // 检查分类是否存在
    const existingCategory = await db.clubCategory.findUnique({
      where: { id },
      include: {
        _count: {
          select: {
            clubs: true
          }
        }
      }
    })

    if (!existingCategory) {
      return NextResponse.json(
        { error: '分类不存在' },
        { status: 404 }
      )
    }

    // 如果修改名称，检查是否与其他分类重名
    if (name && name !== existingCategory.name) {
      const duplicateCategory = await db.clubCategory.findFirst({
        where: { 
          name,
          id: { not: id }
        }
      })

      if (duplicateCategory) {
        return NextResponse.json(
          { error: '分类名称已存在' },
          { status: 400 }
        )
      }
    }

    const category = await db.clubCategory.update({
      where: { id },
      data: {
        name,
        description,
        sort
      }
    })

    return NextResponse.json(category)
  } catch (error) {
    console.error('更新分类失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}

// DELETE - 删除分类
export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // 检查分类是否存在
    const existingCategory = await db.clubCategory.findUnique({
      where: { id },
      include: {
        _count: {
          select: {
            clubs: true
          }
        }
      }
    })

    if (!existingCategory) {
      return NextResponse.json(
        { error: '分类不存在' },
        { status: 404 }
      )
    }

    // 检查该分类下是否有关联的社团
    if (existingCategory._count.clubs > 0) {
      return NextResponse.json(
        { error: '请先移除该分类下的社团' },
        { status: 400 }
      )
    }

    await db.clubCategory.delete({
      where: { id }
    })

    return NextResponse.json({ message: '删除成功' })
  } catch (error) {
    console.error('删除分类失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}