import { db } from '../src/lib/db'

async function seed() {
  try {
    console.log('开始初始化数据...')

    // 创建社团分类
    const categories = await Promise.all([
      db.clubCategory.create({
        data: {
          name: '体育类',
          description: '各类体育健身社团',
          sort: 1
        }
      }),
      db.clubCategory.create({
        data: {
          name: '艺术类',
          description: '音乐、美术、舞蹈等艺术社团',
          sort: 2
        }
      }),
      db.clubCategory.create({
        data: {
          name: '科技类',
          description: '编程、机器人、科学探究等科技社团',
          sort: 3
        }
      }),
      db.clubCategory.create({
        data: {
          name: '学术类',
          description: '文学、辩论、学习等学术社团',
          sort: 4
        }
      })
    ])

    console.log('创建社团分类完成')

    // 创建用户（使用简单密码）
    const adminUser = await db.user.create({
      data: {
        studentId: 'ADMIN001',
        name: '系统管理员',
        email: 'admin@school.edu.cn',
        password: 'admin123', // 简化处理
        role: 'ADMIN',
        major: '计算机科学',
        grade: '2020级'
      }
    })

    // 创建普通学生用户
    const students = await Promise.all([
      db.user.create({
        data: {
          studentId: '2021001',
          name: '张三',
          email: 'zhangsan@student.edu.cn',
          password: 'student123',
          role: 'STUDENT',
          major: '计算机科学',
          grade: '2021级'
        }
      }),
      db.user.create({
        data: {
          studentId: '2021002',
          name: '李四',
          email: 'lisi@student.edu.cn',
          password: 'student123',
          role: 'STUDENT',
          major: '软件工程',
          grade: '2021级'
        }
      }),
      db.user.create({
        data: {
          studentId: '2021003',
          name: '王五',
          email: 'wangwu@student.edu.cn',
          password: 'student123',
          role: 'CLUB_MANAGER',
          major: '数据科学',
          grade: '2020级'
        }
      })
    ])

    console.log('创建用户完成')

    // 创建社团
    const clubs = await Promise.all([
      db.club.create({
        data: {
          name: '篮球社',
          description: '推广篮球运动，增强身体素质',
          categoryId: categories[0].id,
          managerId: students[2].id,
          balance: 8500,
          starRating: 4.8,
          memberCount: 45,
          status: 'ACTIVE',
          establishedAt: new Date('2020-09-01')
        }
      }),
      db.club.create({
        data: {
          name: '编程社',
          description: '学习编程技术，参与项目开发',
          categoryId: categories[2].id,
          managerId: students[0].id,
          balance: 5200,
          starRating: 4.6,
          memberCount: 32,
          status: 'ACTIVE',
          establishedAt: new Date('2020-09-01')
        }
      }),
      db.club.create({
        data: {
          name: '摄影社',
          description: '记录美好瞬间，分享摄影技巧',
          categoryId: categories[1].id,
          balance: 3800,
          starRating: 4.5,
          memberCount: 28,
          status: 'ACTIVE',
          establishedAt: new Date('2021-03-01')
        }
      }),
      db.club.create({
        data: {
          name: '音乐社',
          description: '音乐交流，举办音乐会',
          categoryId: categories[1].id,
          balance: 6200,
          starRating: 4.7,
          memberCount: 35,
          status: 'ACTIVE',
          establishedAt: new Date('2020-09-01')
        }
      }),
      db.club.create({
        data: {
          name: '辩论社',
          description: '锻炼口才，提升思辨能力',
          categoryId: categories[3].id,
          balance: 2500,
          starRating: 4.4,
          memberCount: 22,
          status: 'ACTIVE',
          establishedAt: new Date('2021-09-01')
        }
      })
    ])

    console.log('创建社团完成')

    // 创建社团成员
    await Promise.all([
      // 篮球社成员
      db.clubMember.create({
        data: {
          clubId: clubs[0].id,
          studentId: students[0].id,
          role: 'MEMBER',
          status: 'ACTIVE'
        }
      }),
      db.clubMember.create({
        data: {
          clubId: clubs[0].id,
          studentId: students[1].id,
          role: 'STAFF',
          status: 'ACTIVE'
        }
      }),
      // 编程社成员
      db.clubMember.create({
        data: {
          clubId: clubs[1].id,
          studentId: students[1].id,
          role: 'MEMBER',
          status: 'ACTIVE'
        }
      }),
      db.clubMember.create({
        data: {
          clubId: clubs[1].id,
          studentId: students[2].id,
          role: 'MEMBER',
          status: 'ACTIVE'
        }
      })
    ])

    console.log('创建社团成员完成')

    // 创建活动
    const today = new Date()
    await Promise.all([
      db.activity.create({
        data: {
          clubId: clubs[0].id,
          title: '篮球友谊赛',
          description: '与其他社团进行篮球友谊比赛',
          budget: 500,
          location: '体育馆',
          startTime: new Date(today.getTime() + 2 * 60 * 60 * 1000), // 2小时后
          endTime: new Date(today.getTime() + 4 * 60 * 60 * 1000), // 4小时后
          maxParticipants: 30,
          status: 'APPROVED'
        }
      }),
      db.activity.create({
        data: {
          clubId: clubs[1].id,
          title: '编程技术分享会',
          description: '分享最新的编程技术和项目经验',
          budget: 300,
          location: '计算机楼301',
          startTime: new Date(today.getTime() + 6 * 60 * 60 * 1000), // 6小时后
          endTime: new Date(today.getTime() + 8 * 60 * 60 * 1000), // 8小时后
          maxParticipants: 50,
          status: 'APPROVED'
        }
      }),
      db.activity.create({
        data: {
          clubId: clubs[2].id,
          title: '校园摄影采风',
          description: '春天校园美景摄影活动',
          budget: 200,
          location: '校园各处',
          startTime: new Date(today.getTime() + 24 * 60 * 60 * 1000), // 明天
          endTime: new Date(today.getTime() + 26 * 60 * 60 * 1000),
          maxParticipants: 25,
          status: 'PENDING'
        }
      })
    ])

    console.log('创建活动完成')

    // 创建系统公告
    await Promise.all([
      db.announcement.create({
        data: {
          title: '关于2024年春季社团招新的通知',
          content: '各社团请做好招新准备，具体时间安排请查看附件...',
          type: 'URGENT',
          isPinned: true,
          createdBy: adminUser.id,
          publishAt: new Date()
        }
      }),
      db.announcement.create({
        data: {
          title: '社团经费管理规范更新',
          content: '为规范社团经费使用，特制定以下管理规范...',
          type: 'GENERAL',
          isPinned: false,
          createdBy: adminUser.id,
          publishAt: new Date(Date.now() - 24 * 60 * 60 * 1000) // 1天前
        }
      }),
      db.announcement.create({
        data: {
          title: '系统维护公告',
          content: '系统将于本周六凌晨进行维护升级...',
          type: 'SYSTEM',
          isPinned: false,
          createdBy: adminUser.id,
          publishAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) // 3天前
        }
      })
    ])

    console.log('创建系统公告完成')

    console.log('数据初始化完成！')
    console.log('管理员账号: ADMIN001 / admin123')
    console.log('学生账号: 2021001 / student123')

  } catch (error) {
    console.error('数据初始化失败:', error)
    throw error
  }
}

seed()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })