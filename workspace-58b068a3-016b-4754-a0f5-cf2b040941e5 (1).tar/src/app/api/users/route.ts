import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url!)
    const search = searchParams.get('search')
    const availableForClub = searchParams.get('availableForClub') === 'true'
    
    const where: any = {}
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { studentId: { contains: search } },
        { email: { contains: search } }
      ]
    }

    // 如果是选择社长，只返回角色是社长或未进入社团的用户
    if (availableForClub) {
      where.OR = [
        { role: 'CLUB_MANAGER' },
        { role: 'STUDENT' }
      ]
      where.status = 'ACTIVE'
    }

    const users = await db.user.findMany({
      where,
      select: {
        id: true,
        studentId: true,
        name: true,
        email: true,
        role: true,
        status: true
      },
      orderBy: { createdAt: 'desc' }
    })

    // 如果是选择社长，需要过滤掉已经在其他社团担任社长的用户
    let filteredUsers = users
    if (availableForClub) {
      const clubManagers = await db.club.findMany({
        where: {
          managerId: { not: null }
        },
        select: { managerId: true }
      })
      
      const managerIds = clubManagers.map(cm => cm.managerId).filter(Boolean)
      
      filteredUsers = users.filter(user => 
        user.role === 'STUDENT' && !managerIds.includes(user.id)
      )
    }

    return NextResponse.json({ users: filteredUsers })
  } catch (error) {
    console.error('获取用户列表失败:', error)
    return NextResponse.json(
      { error: '获取用户列表失败', details: error?.message || '未知错误' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { studentId, name, email, role } = await request.json()

    // 验证必填字段
    if (!studentId || !name || !email) {
      return NextResponse.json(
        { error: '学号、姓名和邮箱为必填项' },
        { status: 400 }
      )
    }

    // 检查学号是否已存在
    const existingStudentId = await db.user.findUnique({
      where: { studentId }
    })

    if (existingStudentId) {
      return NextResponse.json(
        { error: '该学号已被使用' },
        { status: 400 }
      )
    }

    // 检查邮箱是否已存在
    const existingEmail = await db.user.findUnique({
      where: { email }
    })

    if (existingEmail) {
      return NextResponse.json(
        { error: '该邮箱已被使用' },
        { status: 400 }
      )
    }

    // 生成默认密码（学号后6位）
    const defaultPassword = studentId.slice(-6)

    // 创建新用户
    const newUser = await db.user.create({
      data: {
        studentId,
        name,
        email,
        password: defaultPassword, // 实际应用中应该加密
        role: role || 'STUDENT',
        status: 'ACTIVE'
      }
    })

    // 这里应该发送邮件通知，暂时模拟
    console.log(`发送邮件到 ${email}: 您的账号已创建，学号：${studentId}，密码：${defaultPassword}`)

    return NextResponse.json({
      message: '用户创建成功',
      user: {
        id: newUser.id,
        studentId: newUser.studentId,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role
      }
    })
  } catch (error) {
    console.error('创建用户失败:', error)
    return NextResponse.json(
      { error: '创建用户失败' },
      { status: 500 }
    )
  }
}