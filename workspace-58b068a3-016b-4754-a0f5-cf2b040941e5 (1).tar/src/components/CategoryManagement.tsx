"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { Plus, Edit, Trash2, GripVertical } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Category {
  id: string
  name: string
  description?: string
  sort: number
  clubCount: number
}

export default function CategoryManagement() {
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [newCategory, setNewCategory] = useState({
    name: '',
    description: '',
    sort: 0
  })
  const { toast } = useToast()

  useEffect(() => {
    fetchCategories()
  }, [])

  const fetchCategories = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/categories')
      if (response.ok) {
        const data = await response.json()
        setCategories(data.sort((a: Category, b: Category) => a.sort - b.sort))
      }
    } catch (error) {
      console.error('获取分类列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreateCategory = async () => {
    try {
      const response = await fetch('/api/categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newCategory),
      })

      if (response.ok) {
        setIsCreateDialogOpen(false)
        setNewCategory({ name: '', description: '', sort: 0 })
        fetchCategories()
        toast({
          title: "创建成功",
          description: "分类创建成功",
        })
      } else {
        const error = await response.json()
        toast({
          variant: "destructive",
          title: "创建失败",
          description: error.error || '创建失败，请检查输入信息',
        })
      }
    } catch (error) {
      console.error('创建分类失败:', error)
      toast({
        variant: "destructive",
        title: "创建失败",
        description: "网络错误，请稍后重试",
      })
    }
  }

  const handleUpdateCategory = async () => {
    if (!editingCategory) return

    try {
      const response = await fetch(`/api/categories/${editingCategory.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: editingCategory.name,
          description: editingCategory.description,
          sort: editingCategory.sort
        }),
      })

      if (response.ok) {
        setEditingCategory(null)
        fetchCategories()
        toast({
          title: "更新成功",
          description: "分类信息已更新",
        })
      } else {
        const error = await response.json()
        toast({
          variant: "destructive",
          title: "更新失败",
          description: error.error || '更新失败，请检查输入信息',
        })
      }
    } catch (error) {
      console.error('更新分类失败:', error)
      toast({
        variant: "destructive",
        title: "更新失败",
        description: "网络错误，请稍后重试",
      })
    }
  }

  const handleDeleteCategory = async (category: Category) => {
    if (category.clubCount > 0) {
      toast({
        variant: "destructive",
        title: "无法删除",
        description: "该分类下还有社团，无法删除",
      })
      return
    }

    if (!confirm(`确定要删除分类"${category.name}"吗？`)) {
      return
    }

    try {
      const response = await fetch(`/api/categories/${category.id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        fetchCategories()
        toast({
          title: "删除成功",
          description: `分类"${category.name}"已删除`,
        })
      } else {
        const error = await response.json()
        toast({
          variant: "destructive",
          title: "删除失败",
          description: error.error || '删除失败，请稍后重试',
        })
      }
    } catch (error) {
      console.error('删除分类失败:', error)
      toast({
        variant: "destructive",
        title: "删除失败",
        description: "网络错误，请稍后重试",
      })
    }
  }

  const openEditDialog = (category: Category) => {
    setEditingCategory({ ...category })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">分类管理</h2>
          <p className="text-muted-foreground">管理社团分类，支持动态维护</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              新建分类
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>创建新分类</DialogTitle>
              <DialogDescription>
                创建新的社团分类，用于分类管理社团。
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">分类名称</Label>
                <Input
                  id="name"
                  value={newCategory.name}
                  onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                  placeholder="请输入分类名称"
                />
              </div>
              <div>
                <Label htmlFor="description">分类描述</Label>
                <Textarea
                  id="description"
                  value={newCategory.description}
                  onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
                  placeholder="请输入分类描述"
                />
              </div>
              <div>
                <Label htmlFor="sort">排序</Label>
                <Input
                  id="sort"
                  type="number"
                  value={newCategory.sort}
                  onChange={(e) => setNewCategory({ ...newCategory, sort: parseInt(e.target.value) || 0 })}
                  placeholder="排序数字，越小越靠前"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                取消
              </Button>
              <Button onClick={handleCreateCategory}>
                创建
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* 分类列表 */}
      <Card>
        <CardHeader>
          <CardTitle>分类列表</CardTitle>
          <CardDescription>共 {categories.length} 个分类</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="animate-pulse space-y-3">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <GripVertical className="h-4 w-4 text-muted-foreground" />
                  </TableHead>
                  <TableHead>分类名称</TableHead>
                  <TableHead>描述</TableHead>
                  <TableHead>排序</TableHead>
                  <TableHead>关联社团数</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {categories.map((category) => (
                  <TableRow key={category.id}>
                    <TableCell>
                      <GripVertical className="h-4 w-4 text-muted-foreground" />
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{category.name}</div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-muted-foreground max-w-xs truncate">
                        {category.description || '-'}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{category.sort}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={category.clubCount > 0 ? 'default' : 'secondary'}>
                        {category.clubCount} 个
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => openEditDialog(category)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleDeleteCategory(category)}
                          disabled={category.clubCount > 0}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* 编辑分类对话框 */}
      <Dialog open={!!editingCategory} onOpenChange={() => setEditingCategory(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>编辑分类</DialogTitle>
            <DialogDescription>
              修改分类信息。
            </DialogDescription>
          </DialogHeader>
          {editingCategory && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-name">分类名称</Label>
                <Input
                  id="edit-name"
                  value={editingCategory.name}
                  onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                  placeholder="请输入分类名称"
                />
              </div>
              <div>
                <Label htmlFor="edit-description">分类描述</Label>
                <Textarea
                  id="edit-description"
                  value={editingCategory.description || ''}
                  onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                  placeholder="请输入分类描述"
                />
              </div>
              <div>
                <Label htmlFor="edit-sort">排序</Label>
                <Input
                  id="edit-sort"
                  type="number"
                  value={editingCategory.sort}
                  onChange={(e) => setEditingCategory({ ...editingCategory, sort: parseInt(e.target.value) || 0 })}
                  placeholder="排序数字，越小越靠前"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingCategory(null)}>
              取消
            </Button>
            <Button onClick={handleUpdateCategory}>
              更新
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}