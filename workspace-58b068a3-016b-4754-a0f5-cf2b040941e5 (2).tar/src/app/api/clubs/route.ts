import { NextRequest, NextResponse } from "next/server"
import { db } from '@/lib/db'

// GET - 获取社团列表
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url!)
    const categoryId = searchParams.get('categoryId')
    const status = searchParams.get('status')
    const search = searchParams.get('search')
    const page = parseInt(searchParams.get('page') || '1')
    const pageSize = parseInt(searchParams.get('pageSize') || '10')

    const where: any = {}
    if (categoryId && categoryId !== 'all') where.categoryId = categoryId
    if (status && status !== 'all') where.status = status
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { description: { contains: search } }
      ]
    }

    const [clubs, total] = await Promise.all([
      db.club.findMany({
        where,
        include: {
          category: true,
          manager: {
            select: {
              id: true,
              name: true,
              studentId: true
            }
          },
          _count: {
            select: {
              members: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      db.club.count({ where })
    ])

    return NextResponse.json({
      clubs: clubs.map(club => ({
        ...club,
        memberCount: club._count.members
      })),
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize)
    })
  } catch (error) {
    console.error('获取社团列表失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}

// POST - 创建社团
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const name = formData.get('name') as string
    const description = formData.get('description') as string
    const categoryId = formData.get('categoryId') as string
    const managerId = formData.get('managerId') as string
    const logoFile = formData.get('logo') as File

    // 检查社团名称是否已存在
    const existingClub = await db.club.findFirst({
      where: { name }
    })

    if (existingClub) {
      return NextResponse.json(
        { error: '社团名称已存在' },
        { status: 400 }
      )
    }

    // 处理logo上传
    let logoUrl = null
    if (logoFile && logoFile.size > 0) {
      const bytes = await logoFile.arrayBuffer()
      const base64 = Buffer.from(bytes).toString('base64')
      logoUrl = `data:${logoFile.type};base64,${base64}`
    }

    const club = await db.club.create({
      data: {
        name,
        description,
        categoryId,
        managerId,
        logo: logoUrl,
        status: 'ACTIVE', // 直接设置为活跃状态
        memberCount: 1, // 社长自动成为第一个成员
        establishedAt: new Date()
      },
      include: {
        category: true,
        manager: {
          select: {
            id: true,
            name: true,
            studentId: true
          }
        }
      }
    })

    // 将社长添加到社团成员中
    await db.clubMember.create({
      data: {
        clubId: club.id,
        studentId: managerId,
        role: 'MANAGER',
        status: 'ACTIVE',
        joinedAt: new Date()
      }
    })

    // 更新用户角色为社长（如果还不是）
    await db.user.update({
      where: { id: managerId },
      data: { role: 'CLUB_MANAGER' }
    })

    console.log(`社团创建成功，社长 ${managerId} 已自动加入社团`)

    return NextResponse.json(club)
  } catch (error) {
    console.error('创建社团失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}