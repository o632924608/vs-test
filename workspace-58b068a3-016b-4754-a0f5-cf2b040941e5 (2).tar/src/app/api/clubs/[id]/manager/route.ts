import { NextRequest, NextResponse } from "next/server"
import { db } from '@/lib/db'

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const clubId = params.id
    const { managerId } = await request.json()

    if (!clubId || !managerId) {
      return NextResponse.json(
        { error: '社团ID和用户ID不能为空' },
        { status: 400 }
      )
    }

    // 验证社团是否存在
    const club = await db.club.findUnique({
      where: { id: clubId },
      include: {
        members: true
      }
    })

    if (!club) {
      return NextResponse.json(
        { error: '社团不存在' },
        { status: 404 }
      )
    }

    // 验证用户是否是社团成员
    const member = await db.clubMember.findFirst({
      where: {
        clubId,
        studentId: managerId
      }
    })

    if (!member) {
      return NextResponse.json(
        { error: '该用户不是社团成员或已退出' },
        { status: 400 }
      )
    }

    // 如果有现任社长，先将其降为普通会员
    if (club.managerId) {
      await db.clubMember.updateMany({
        where: {
          clubId,
          studentId: club.managerId,
          role: 'MANAGER'
        },
        data: {
          role: 'MEMBER'
        }
      })
    }

    // 使用事务更新社长信息
    await db.$transaction(async (tx) => {
      // 更新社团的社长
      await tx.club.update({
        where: { id: clubId },
        data: { managerId }
      })

      // 将新社长设置为MANAGER角色
      await tx.clubMember.updateMany({
        where: {
          clubId,
          studentId: managerId
        },
        data: {
          role: 'MANAGER'
        }
      })

      // 更新用户角色为CLUB_MANAGER
      await tx.user.update({
        where: { id: managerId },
        data: { role: 'CLUB_MANAGER' }
      })

      // 如果原社长存在且不是同一个人，将其角色改回STUDENT
      if (club.managerId && club.managerId !== managerId) {
        await tx.user.update({
          where: { id: club.managerId },
          data: { role: 'STUDENT' }
        })
      }
    })

    return NextResponse.json({
      message: '社长设置成功'
    })
  } catch (error) {
    console.error('设置社长失败:', error)
    return NextResponse.json(
      { error: '设置社长失败' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const clubId = params.id

    if (!clubId) {
      return NextResponse.json(
        { error: '社团ID不能为空' },
        { status: 400 }
      )
    }

    // 验证社团是否存在
    const club = await db.club.findUnique({
      where: { id: clubId }
    })

    if (!club) {
      return NextResponse.json(
        { error: '社团不存在' },
        { status: 404 }
      )
    }

    if (!club.managerId) {
      return NextResponse.json(
        { error: '该社团目前没有社长' },
        { status: 400 }
      )
    }

    // 使用事务处理社长退位
    await db.$transaction(async (tx) => {
      // 清除社团的社长
      await tx.club.update({
        where: { id: clubId },
        data: { managerId: null }
      })

      // 将原社长降为普通会员
      await tx.clubMember.updateMany({
        where: {
          clubId,
          studentId: club.managerId
        },
        data: {
          role: 'MEMBER'
        }
      })

      // 将原社长用户角色改回STUDENT
      await tx.user.update({
        where: { id: club.managerId },
        data: { role: 'STUDENT' }
      })
    })

    return NextResponse.json({
      message: '社长退位成功'
    })
  } catch (error) {
    console.error('社长退位失败:', error)
    return NextResponse.json(
      { error: '社长退位失败' },
      { status: 500 }
    )
  }
}