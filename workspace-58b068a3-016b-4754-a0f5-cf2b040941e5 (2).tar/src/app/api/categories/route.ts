import { NextResponse } from "next/server"
import { db } from '@/lib/db'

// GET - 获取分类列表
export async function GET() {
  try {
    const categories = await db.clubCategory.findMany({
      include: {
        _count: {
          select: {
            clubs: true
          }
        }
      },
      orderBy: { sort: 'asc' }
    })

    return NextResponse.json(
      categories.map(cat => ({
        ...cat,
        clubCount: cat._count.clubs
      }))
    )
  } catch (error) {
    console.error('获取分类列表失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}

// POST - 创建分类
export async function POST(request: Request) {
  try {
    const data = await request.json()
    const { name, description, sort } = data

    // 检查分类名称是否已存在
    const existingCategory = await db.clubCategory.findFirst({
      where: { name }
    })

    if (existingCategory) {
      return NextResponse.json(
        { error: '分类名称已存在' },
        { status: 400 }
      )
    }

    const category = await db.clubCategory.create({
      data: {
        name,
        description,
        sort: sort || 0
      }
    })

    return NextResponse.json(category)
  } catch (error) {
    console.error('创建分类失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}