import { NextResponse } from "next/server"
import { db } from '@/lib/db'

// PUT - 审批转社申请
export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const data = await request.json()
    const { action, note, approverId } = data

    if (!action || !['APPROVE', 'REJECT'].includes(action)) {
      return NextResponse.json(
        { error: '操作类型错误' },
        { status: 400 }
      )
    }

    // 获取转社申请
    const transfer = await db.clubTransferApply.findUnique({
      where: { id },
      include: {
        student: true,
        fromClub: true,
        toClub: true
      }
    })

    if (!transfer) {
      return NextResponse.json(
        { error: '转社申请不存在' },
        { status: 404 }
      )
    }

    // 使用事务处理审批
    const result = await db.$transaction(async (tx) => {
      let updatedTransfer

      if (action === 'REJECT') {
        // 驳回申请
        updatedTransfer = await tx.clubTransferApply.update({
          where: { id },
          data: {
            auditStatus: 'REJECTED',
            fromManagerNote: note,
            toManagerNote: note
          }
        })
      } else if (action === 'APPROVE') {
        // 同意申请
        if (transfer.auditStatus === 'PENDING_FROM') {
          // 原社团同意，更新状态为待目标社团审批
          updatedTransfer = await tx.clubTransferApply.update({
            where: { id },
            data: {
              auditStatus: 'PENDING_TO',
              fromManagerNote: note
            }
          })
        } else if (transfer.auditStatus === 'PENDING_TO') {
          // 目标社团同意，完成转社
          updatedTransfer = await tx.clubTransferApply.update({
            where: { id },
            data: {
              auditStatus: 'APPROVED',
              toManagerNote: note
            }
          })

          // 1. 将原社团成员状态设为已退出
          await tx.clubMember.updateMany({
            where: {
              clubId: transfer.fromClubId,
              studentId: transfer.studentId,
              status: 'ACTIVE'
            },
            data: {
              status: 'INACTIVE',
              leftAt: new Date(),
              reason: '转社'
            }
          })

          // 2. 在目标社团创建新成员记录
          await tx.clubMember.create({
            data: {
              clubId: transfer.toClubId,
              studentId: transfer.studentId,
              role: 'MEMBER',
              status: 'ACTIVE',
              joinedAt: new Date()
            }
          })
        }
      }

      return updatedTransfer
    })

    return NextResponse.json({
      message: action === 'APPROVE' ? '审批通过' : '审批驳回',
      transfer: result
    })
  } catch (error) {
    console.error('审批转社申请失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}