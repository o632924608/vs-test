import { NextResponse } from "next/server"
import { db } from '@/lib/db'

// GET - 获取转社申请列表
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const clubId = searchParams.get('clubId')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')

    const where: any = {}
    if (status) where.auditStatus = status
    if (clubId) {
      where.OR = [
        { fromClubId: clubId },
        { toClubId: clubId }
      ]
    }

    const [transfers, total] = await Promise.all([
      db.clubTransferApply.findMany({
        where,
        include: {
          student: {
            select: {
              id: true,
              studentId: true,
              name: true,
              email: true,
              major: true,
              grade: true
            }
          },
          fromClub: {
            select: {
              id: true,
              name: true
            }
          },
          toClub: {
            select: {
              id: true,
              name: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      db.clubTransferApply.count({ where })
    ])

    return NextResponse.json({
      transfers,
      total,
      page,
      totalPages: Math.ceil(total / limit)
    })
  } catch (error) {
    console.error('获取转社申请列表失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}

// POST - 创建转社申请
export async function POST(request: Request) {
  try {
    const data = await request.json()
    const { studentId, fromClubId, toClubId, reason } = data

    // 检查学生是否存在
    const student = await db.user.findUnique({
      where: { id: studentId }
    })

    if (!student) {
      return NextResponse.json(
        { error: '学生不存在' },
        { status: 400 }
      )
    }

    // 检查是否在原社团中
    const fromMember = await db.clubMember.findFirst({
      where: {
        clubId: fromClubId,
        studentId,
        status: 'ACTIVE'
      }
    })

    if (!fromMember) {
      return NextResponse.json(
        { error: '不在原社团中' },
        { status: 400 }
      )
    }

    // 检查是否已在目标社团中
    const toMember = await db.clubMember.findFirst({
      where: {
        clubId: toClubId,
        studentId,
        status: 'ACTIVE'
      }
    })

    if (toMember) {
      return NextResponse.json(
        { error: '已在目标社团中' },
        { status: 400 }
      )
    }

    // 检查是否已有待处理的转社申请
    const existingTransfer = await db.clubTransferApply.findFirst({
      where: {
        studentId,
        auditStatus: {
          in: ['PENDING_FROM', 'PENDING_TO']
        }
      }
    })

    if (existingTransfer) {
      return NextResponse.json(
        { error: '已有待处理的转社申请' },
        { status: 400 }
      )
    }

    const transfer = await db.clubTransferApply.create({
      data: {
        studentId,
        fromClubId,
        toClubId,
        reason,
        auditStatus: 'PENDING_FROM'
      },
      include: {
        student: {
          select: {
            id: true,
            studentId: true,
            name: true,
            email: true,
            major: true,
            grade: true
          }
        },
        fromClub: {
          select: {
            id: true,
            name: true
          }
        },
        toClub: {
          select: {
            id: true,
            name: true
          }
        }
      }
    })

    return NextResponse.json(transfer)
  } catch (error) {
    console.error('创建转社申请失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}