import { NextResponse } from "next/server";
import { db } from '@/lib/db'

export async function GET() {
  try {
    // 获取基础统计数据
    const totalClubs = await db.club.count()
    const totalStudents = await db.user.count()
    const todayActivities = await db.activity.count({
      where: {
        startTime: {
          gte: new Date(new Date().setHours(0, 0, 0, 0)),
          lt: new Date(new Date().setHours(23, 59, 59, 999))
        }
      }
    })
    
    // 获取待审批数量
    const pendingClubs = await db.club.count({ where: { status: 'PENDING' } })
    const pendingActivities = await db.activity.count({ where: { status: 'PENDING' } })
    const pendingResources = await db.resourceApply.count({ where: { status: 'PENDING' } })
    const pendingTransfers = await db.clubTransferApply.count({
      where: { auditStatus: { in: ['PENDING_FROM', 'PENDING_TO'] } }
    })
    
    const pendingApprovals = pendingClubs + pendingActivities + pendingResources + pendingTransfers

    // 获取社团分类统计
    const categories = await db.clubCategory.findMany({
      include: {
        clubs: true
      }
    })

    const categoryStats = categories.map(cat => ({
      name: cat.name,
      count: cat.clubs.length,
      percentage: 0 // 将在前端计算
    }))

    // 获取活跃社团排行 (按活动数量)
    const activeClubs = await db.club.findMany({
      include: {
        activities: {
          where: {
            startTime: {
              gte: new Date(new Date().setMonth(new Date().getMonth() - 3)) // 最近3个月
            }
          }
        }
      },
      orderBy: {
        activities: {
          _count: 'desc'
        }
      },
      take: 10
    })

    const activeClubStats = activeClubs.map(club => ({
      name: club.name,
      activities: club.activities.length
    }))

    // 获取系统公告
    const announcements = await db.announcement.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10
    })

    return NextResponse.json({
      stats: {
        totalClubs,
        totalStudents,
        todayActivities,
        pendingApprovals
      },
      categories: categoryStats,
      activeClubs: activeClubStats,
      announcements
    })
  } catch (error) {
    console.error('API Error:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}