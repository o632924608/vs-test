import { NextResponse } from "next/server"
import { db } from '@/lib/db'

// POST - 批量导入成员预检查
export async function POST(request: Request) {
  try {
    const data = await request.json()
    const { clubId, members } = data

    if (!clubId || !members || !Array.isArray(members)) {
      return NextResponse.json(
        { error: '参数错误' },
        { status: 400 }
      )
    }

    // 检查社团是否存在
    const club = await db.club.findUnique({
      where: { id: clubId }
    })

    if (!club) {
      return NextResponse.json(
        { error: '社团不存在' },
        { status: 400 }
      )
    }

    const results = []

    for (const member of members) {
      const { studentId, name, email } = member
      
      // 检查学号是否存在
      const student = await db.user.findUnique({
        where: { studentId }
      })

      if (!student) {
        results.push({
          ...member,
          status: 'INVALID',
          errorMsg: '学号不存在，需要注册账号'
        })
        continue
      }

      // 检查是否已在该社团
      const existingMember = await db.clubMember.findFirst({
        where: {
          clubId,
          studentId: student.id
        }
      })

      if (existingMember) {
        results.push({
          ...member,
          status: 'INVALID',
          errorMsg: '已在该社团中'
        })
        continue
      }

      results.push({
        ...member,
        status: 'VALID',
        errorMsg: null,
        studentId: student.id
      })
    }

    return NextResponse.json({
      results,
      total: results.length,
      valid: results.filter(r => r.status === 'VALID').length,
      invalid: results.filter(r => r.status === 'INVALID').length
    })
  } catch (error) {
    console.error('批量导入预检查失败:', error)
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    )
  }
}