import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url!)
    const clubId = searchParams.get('clubId')
    const search = searchParams.get('search')
    const role = searchParams.get('role')
    const page = parseInt(searchParams.get('page') || '1')
    const pageSize = parseInt(searchParams.get('pageSize') || '10')
    
    if (!clubId) {
      return NextResponse.json(
        { error: '社团ID不能为空' },
        { status: 400 }
      )
    }
    
    const where: any = { clubId }
    if (search) {
      where.OR = [
        { student: { name: { contains: search } } },
        { student: { email: { contains: search } } },
        { student: { studentId: { contains: search } } }
      ]
    }
    if (role && role !== 'all') {
      where.role = role
    }

    const [members, total] = await Promise.all([
      db.clubMember.findMany({
        where,
        include: {
          student: {
            select: {
              id: true,
              studentId: true,
              name: true,
              email: true
            }
          }
        },
        orderBy: { joinedAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize
      }),
      db.clubMember.count({ where })
    ])

    return NextResponse.json({
      members,
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize)
    })
  } catch (error) {
    console.error('获取成员列表失败:', error)
    return NextResponse.json(
      { error: '获取成员列表失败' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const { studentId, name, email, clubId, role } = data

    // 检查是否已存在
    const existingMember = await db.clubMember.findFirst({
      where: {
        studentId,
        clubId
      }
    })

    if (existingMember) {
      return NextResponse.json(
        { error: '该学生已在此社团中' },
        { status: 400 }
      )
    }

    const member = await db.clubMember.create({
      data: {
        studentId,
        name,
        email,
        clubId,
        role: role || 'MEMBER',
        status: 'ACTIVE',
        joinedAt: new Date()
      }
    })

    // 模拟发送邮件通知
    console.log(`成员添加成功通知已发送给: ${email}`)

    return NextResponse.json(member)
  } catch (error) {
    console.error('添加成员失败:', error)
    return NextResponse.json(
      { error: '添加成员失败' },
      { status: 500 }
    )
  }
}