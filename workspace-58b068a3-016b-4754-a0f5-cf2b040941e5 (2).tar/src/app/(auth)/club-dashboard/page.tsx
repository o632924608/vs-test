"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Users, 
  DollarSign, 
  CheckCircle, 
  Plus,
  FileText,
  CreditCard,
  UserPlus
} from 'lucide-react'

export default function ClubDashboard() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchClubData()
  }, [])

  const todoItems = [
    { type: '入社申请', count: 3, color: 'bg-blue-500' },
    { type: '转社申请', count: 1, color: 'bg-orange-500' },
    { type: '活动审批', count: 2, color: 'bg-green-500' },
    { type: '物资申请', count: 1, color: 'bg-purple-500' }
  ]

  const fetchClubData = async () => {
    try {
      // 这里应该获取当前用户管理的社团数据
      // 暂时使用模拟数据
      setTimeout(() => {
        setData({
          memberCount: 45,
          balance: 8500,
          starRating: 4.8
        })
        setLoading(false)
      }, 1000)
    } catch (error) {
      console.error('获取社团数据失败:', error)
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* 本社团概况 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">成员总数</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{loading ? '...' : data?.memberCount || 0}</div>
            <p className="text-xs text-muted-foreground">本月新增 5 人</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">当前经费</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">¥{loading ? '...' : (data?.balance || 0).toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">本学期收入 ¥12,000</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">社团评分</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{loading ? '...' : data?.starRating || 0}</div>
            <p className="text-xs text-muted-foreground">五星社团</p>
          </CardContent>
        </Card>
      </div>

      {/* 待办事项 */}
      <Card>
        <CardHeader>
          <CardTitle>待办事项</CardTitle>
          <CardDescription>需要处理的申请和任务</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {todoItems.map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${item.color}`} />
                  <span className="text-sm font-medium">{item.type}</span>
                </div>
                <Badge variant="secondary">{item.count} 条待处理</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 快捷入口 */}
      <Card>
        <CardHeader>
          <CardTitle>快捷操作</CardTitle>
          <CardDescription>常用功能入口</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button className="h-16 flex flex-col space-y-2">
              <Plus className="h-5 w-5" />
              <span className="text-xs">发布活动</span>
            </Button>
            <Button variant="outline" className="h-16 flex flex-col space-y-2">
              <CreditCard className="h-5 w-5" />
              <span className="text-xs">财务记账</span>
            </Button>
            <Button variant="outline" className="h-16 flex flex-col space-y-2">
              <UserPlus className="h-5 w-5" />
              <span className="text-xs">成员导入</span>
            </Button>
            <Button variant="outline" className="h-16 flex flex-col space-y-2">
              <FileText className="h-5 w-5" />
              <span className="text-xs">申请物资</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}