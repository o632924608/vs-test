"use client"

import CategoryManagement from '@/components/CategoryManagement'

export default function CategoriesPage() {
  return <CategoryManagement />
}