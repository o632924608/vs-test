"use client"

import { useState, useEffect } from 'react'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { 
  Users, 
  Calendar, 
  DollarSign, 
  CheckCircle, 
  Clock, 
  TrendingUp,
  Plus,
  FileText,
  CreditCard,
  UserPlus
} from 'lucide-react'

interface DashboardStats {
  totalClubs: number
  totalStudents: number
  todayActivities: number
  pendingApprovals: number
}

interface Category {
  name: string
  count: number
  percentage: number
}

interface ActiveClub {
  name: string
  activities: number
}

interface Announcement {
  id: string
  title: string
  content: string
  type: 'URGENT' | 'GENERAL' | 'SYSTEM'
  isPinned: boolean
  createdAt: string
}

interface ApiResponse {
  stats: DashboardStats
  categories: Category[]
  activeClubs: ActiveClub[]
  announcements: Announcement[]
}

export default function Dashboard() {
  const [data, setData] = useState<ApiResponse | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const todoItems = [
    { type: '入社申请', count: 3, color: 'bg-blue-500' },
    { type: '转社申请', count: 1, color: 'bg-orange-500' },
    { type: '活动审批', count: 2, color: 'bg-green-500' },
    { type: '物资申请', count: 1, color: 'bg-purple-500' }
  ]

  const fetchDashboardData = async () => {
    try {
      const response = await fetch('/api')
      if (response.ok) {
        const result = await response.json()
        
        // 计算分类百分比
        const totalClubs = result.categories.reduce((sum: number, cat: Category) => sum + cat.count, 0)
        const categoriesWithPercentage = result.categories.map((cat: Category) => ({
          ...cat,
          percentage: totalClubs > 0 ? Math.round((cat.count / totalClubs) * 100) : 0
        }))

        setData({
          ...result,
          categories: categoriesWithPercentage
        })
      }
    } catch (error) {
      console.error('获取数据失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))
    
    if (diffInHours < 1) return '刚刚'
    if (diffInHours < 24) return `${diffInHours}小时前`
    if (diffInHours < 48) return '1天前'
    return `${Math.floor(diffInHours / 24)}天前`
  }

  return (
    <div className="space-y-6">
      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">全校社团总数</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{loading ? '...' : data?.stats.totalClubs || 0}</div>
            <p className="text-xs text-muted-foreground">活跃社团 {data?.stats.totalClubs || 0} 个</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">注册学生总数</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{loading ? '...' : data?.stats.totalStudents || 0}</div>
            <p className="text-xs text-muted-foreground">本学期新增 156 人</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">今日活动数</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{loading ? '...' : data?.stats.todayActivities || 0}</div>
            <p className="text-xs text-muted-foreground">本周累计 24 场</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">待办审批</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{loading ? '...' : data?.stats.pendingApprovals || 0}</div>
            <p className="text-xs text-muted-foreground">需要处理</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 社团分类占比 */}
        <Card>
          <CardHeader>
            <CardTitle>社团分类分布</CardTitle>
            <CardDescription>各类别社团数量占比</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {loading ? (
                <div className="animate-pulse space-y-3">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="h-4 bg-gray-200 rounded"></div>
                  ))}
                </div>
              ) : (
                data?.categories.map((category, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full bg-${['blue', 'green', 'orange', 'purple'][index % 4]}-500`} />
                      <span className="text-sm font-medium">{category.name}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-muted-foreground">{category.count}个</span>
                      <Badge variant="secondary">{category.percentage}%</Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* 活跃度排行 */}
        <Card>
          <CardHeader>
            <CardTitle>社团活跃度排行</CardTitle>
            <CardDescription>本学期举办活动次数 Top 10</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {loading ? (
                <div className="animate-pulse space-y-3">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="h-4 bg-gray-200 rounded"></div>
                  ))}
                </div>
              ) : (
                data?.activeClubs.map((club, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold">
                        {index + 1}
                      </div>
                      <span className="text-sm font-medium">{club.name}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="h-4 w-4 text-green-500" />
                      <span className="text-sm font-medium">{club.activities}</span>
                      <span className="text-xs text-muted-foreground">场活动</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 系统公告 */}
      <Card>
        <CardHeader>
          <CardTitle>系统公告</CardTitle>
          <CardDescription>重要通知和公告</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {loading ? (
              <div className="animate-pulse space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-4 bg-gray-200 rounded"></div>
                ))}
              </div>
            ) : (
              data?.announcements.map((announcement, index) => (
                <div key={index} className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <h4 className="text-sm font-medium">{announcement.title}</h4>
                      <Badge variant={announcement.type === 'URGENT' ? 'destructive' : 'secondary'}>
                        {announcement.type === 'URGENT' ? '紧急' : announcement.type === 'SYSTEM' ? '系统' : '通用'}
                      </Badge>
                      {announcement.isPinned && <Badge variant="outline">置顶</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{formatTimeAgo(announcement.createdAt)}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}