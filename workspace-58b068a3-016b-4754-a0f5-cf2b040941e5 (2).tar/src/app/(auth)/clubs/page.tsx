"use client"

import ClubManagement from '@/components/ClubManagement'

export default function ClubsPage() {
  return <ClubManagement />
}