"use client"

import { usePathname } from 'next/navigation'
import AppLayout from '@/components/AppLayout'

export default function RouteLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()
  
  // 如果是根路径，使用AppLayout（包含登录逻辑）
  if (pathname === '/') {
    return <AppLayout>{children}</AppLayout>
  }
  
  // 其他路径也使用AppLayout，但不需要登录检查（因为AppLayout内部会处理）
  return <AppLayout>{children}</AppLayout>
}