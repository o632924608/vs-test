"use client"

import TransferManagement from '@/components/TransferManagement'

export default function TransfersPage() {
  return <TransferManagement />
}