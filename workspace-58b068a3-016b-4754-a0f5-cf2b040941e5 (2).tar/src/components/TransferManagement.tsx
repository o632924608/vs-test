"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { 
  FileText, 
  Search, 
  Filter,
  CheckCircle,
  XCircle,
  Clock,
  ArrowRight
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface Transfer {
  id: string
  reason?: string
  auditStatus: string
  fromManagerNote?: string
  toManagerNote?: string
  createdAt: string
  student: {
    id: string
    studentId: string
    name: string
    email: string
    major?: string
    grade?: string
  }
  fromClub: {
    id: string
    name: string
  }
  toClub: {
    id: string
    name: string
  }
}

interface Club {
  id: string
  name: string
}

export default function TransferManagement() {
  const [transfers, setTransfers] = useState<Transfer[]>([])
  const [clubs, setClubs] = useState<Club[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isAuditDialogOpen, setIsAuditDialogOpen] = useState(false)
  const [auditingTransfer, setAuditingTransfer] = useState<Transfer | null>(null)
  const [newTransfer, setNewTransfer] = useState({
    studentId: '',
    fromClubId: '',
    toClubId: '',
    reason: ''
  })
  const [auditForm, setAuditForm] = useState({
    action: '',
    note: ''
  })
  const { toast } = useToast()

  useEffect(() => {
    fetchTransfers()
    fetchClubs()
  }, [searchTerm, selectedStatus])

  const fetchTransfers = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (selectedStatus && selectedStatus !== 'all') params.append('status', selectedStatus)
      
      const response = await fetch(`/api/transfers?${params.toString()}`)
      if (response.ok) {
        const data = await response.json()
        let filteredTransfers = data.transfers
        
        if (searchTerm) {
          filteredTransfers = filteredTransfers.filter((transfer: Transfer) =>
            transfer.student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            transfer.student.studentId.toLowerCase().includes(searchTerm.toLowerCase()) ||
            transfer.fromClub.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            transfer.toClub.name.toLowerCase().includes(searchTerm.toLowerCase())
          )
        }
        
        setTransfers(filteredTransfers)
      }
    } catch (error) {
      console.error('获取转社申请列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchClubs = async () => {
    try {
      const response = await fetch('/api/clubs')
      if (response.ok) {
        const data = await response.json()
        setClubs(data.clubs)
      }
    } catch (error) {
      console.error('获取社团列表失败:', error)
    }
  }

  const handleCreateTransfer = async () => {
    try {
      const response = await fetch('/api/transfers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newTransfer),
      })

      if (response.ok) {
        setIsCreateDialogOpen(false)
        setNewTransfer({ studentId: '', fromClubId: '', toClubId: '', reason: '' })
        fetchTransfers()
        toast({
          title: "创建成功",
          description: "转社申请创建成功",
        })
      } else {
        const error = await response.json()
        toast({
          variant: "destructive",
          title: "创建失败",
          description: error.error || '创建失败，请检查输入信息',
        })
      }
    } catch (error) {
      console.error('创建转社申请失败:', error)
      toast({
        variant: "destructive",
        title: "创建失败",
        description: "网络错误，请稍后重试",
      })
    }
  }

  const handleAudit = async () => {
    if (!auditingTransfer) return

    try {
      const response = await fetch(`/api/transfers/${auditingTransfer.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: auditForm.action,
          note: auditForm.note,
          approverId: 'current-user-id' // 实际应用中应该从认证状态获取
        }),
      })

      if (response.ok) {
        setIsAuditDialogOpen(false)
        setAuditingTransfer(null)
        setAuditForm({ action: '', note: '' })
        fetchTransfers()
        toast({
          title: "审批成功",
          description: "转社申请审批成功",
        })
      } else {
        const error = await response.json()
        toast({
          variant: "destructive",
          title: "审批失败",
          description: error.error || '审批失败，请稍后重试',
        })
      }
    } catch (error) {
      console.error('审批失败:', error)
      toast({
        variant: "destructive",
        title: "审批失败",
        description: "网络错误，请稍后重试",
      })
    }
  }

  const openAuditDialog = (transfer: Transfer) => {
    setAuditingTransfer(transfer)
    setAuditForm({ action: '', note: '' })
    setIsAuditDialogOpen(true)
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      'PENDING_FROM': { label: '待原社团审批', variant: 'secondary' as const, icon: <Clock className="h-3 w-3" /> },
      'PENDING_TO': { label: '待目标社团审批', variant: 'secondary' as const, icon: <Clock className="h-3 w-3" /> },
      'APPROVED': { label: '已通过', variant: 'default' as const, icon: <CheckCircle className="h-3 w-3" /> },
      'REJECTED': { label: '已驳回', variant: 'destructive' as const, icon: <XCircle className="h-3 w-3" /> }
    }
    return statusMap[status as keyof typeof statusMap] || { label: status, variant: 'secondary' as const, icon: null }
  }

  const canAudit = (transfer: Transfer) => {
    // 这里应该根据当前用户角色判断是否有权限审批
    // 简化处理，假设所有待审批的都可以审批
    return transfer.auditStatus === 'PENDING_FROM' || transfer.auditStatus === 'PENDING_TO'
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">转社申请管理</h2>
          <p className="text-muted-foreground">处理学生的转社申请，管理社团成员流动</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <FileText className="h-4 w-4 mr-2" />
              新建申请
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>创建转社申请</DialogTitle>
              <DialogDescription>
                为学生创建转社申请，需要原社团和目标社团审批。
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="studentId">学生学号</Label>
                <Input
                  id="studentId"
                  value={newTransfer.studentId}
                  onChange={(e) => setNewTransfer({ ...newTransfer, studentId: e.target.value })}
                  placeholder="请输入学生学号"
                />
              </div>
              <div>
                <Label htmlFor="fromClubId">原社团</Label>
                <Select value={newTransfer.fromClubId} onValueChange={(value) => setNewTransfer({ ...newTransfer, fromClubId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="选择原社团" />
                  </SelectTrigger>
                  <SelectContent>
                    {clubs.map((club) => (
                      <SelectItem key={club.id} value={club.id}>
                        {club.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="toClubId">目标社团</Label>
                <Select value={newTransfer.toClubId} onValueChange={(value) => setNewTransfer({ ...newTransfer, toClubId: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="选择目标社团" />
                  </SelectTrigger>
                  <SelectContent>
                    {clubs.map((club) => (
                      <SelectItem key={club.id} value={club.id}>
                        {club.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="reason">转社原因</Label>
                <Textarea
                  id="reason"
                  value={newTransfer.reason}
                  onChange={(e) => setNewTransfer({ ...newTransfer, reason: e.target.value })}
                  placeholder="请输入转社原因"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                取消
              </Button>
              <Button onClick={handleCreateTransfer}>
                创建申请
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* 筛选器 */}
      <Card>
        <CardHeader>
          <CardTitle>筛选条件</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="search">搜索</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="搜索学生、社团名称"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-8"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="status">状态</Label>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="选择状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="PENDING_FROM">待原社团审批</SelectItem>
                  <SelectItem value="PENDING_TO">待目标社团审批</SelectItem>
                  <SelectItem value="APPROVED">已通过</SelectItem>
                  <SelectItem value="REJECTED">已驳回</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button variant="outline" onClick={() => {
                setSearchTerm('')
                setSelectedStatus('all')
              }}>
                <Filter className="h-4 w-4 mr-2" />
                重置筛选
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 转社申请列表 */}
      <Card>
        <CardHeader>
          <CardTitle>转社申请列表</CardTitle>
          <CardDescription>共找到 {transfers.length} 条申请</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="animate-pulse space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>学生信息</TableHead>
                  <TableHead>转社信息</TableHead>
                  <TableHead>申请原因</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead>申请时间</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transfers.map((transfer) => (
                  <TableRow key={transfer.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{transfer.student.name}</div>
                        <div className="text-sm text-muted-foreground">{transfer.student.studentId}</div>
                        <div className="text-sm text-muted-foreground">{transfer.student.email}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <div>
                          <Badge variant="outline">{transfer.fromClub.name}</Badge>
                        </div>
                        <ArrowRight className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <Badge variant="outline">{transfer.toClub.name}</Badge>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="max-w-xs truncate text-sm">
                        {transfer.reason || '-'}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadge(transfer.auditStatus).variant}>
                        {getStatusBadge(transfer.auditStatus).icon}
                        <span className="ml-1">
                          {getStatusBadge(transfer.auditStatus).label}
                        </span>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(transfer.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        {canAudit(transfer) && (
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => openAuditDialog(transfer)}
                          >
                            审批
                          </Button>
                        )}
                        <Button variant="outline" size="sm">
                          查看
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* 审批对话框 */}
      <Dialog open={isAuditDialogOpen} onOpenChange={setIsAuditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>审批转社申请</DialogTitle>
            <DialogDescription>
              {auditingTransfer && (
                <div className="mt-2">
                  <p><strong>学生：</strong>{auditingTransfer.student.name} ({auditingTransfer.student.studentId})</p>
                  <p><strong>转社：</strong>{auditingTransfer.fromClub.name} → {auditingTransfer.toClub.name}</p>
                  <p><strong>原因：</strong>{auditingTransfer.reason || '无'}</p>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="action">审批结果</Label>
              <Select value={auditForm.action} onValueChange={(value) => setAuditForm({ ...auditForm, action: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="选择审批结果" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="APPROVE">通过</SelectItem>
                  <SelectItem value="REJECT">驳回</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="note">审批备注</Label>
              <Textarea
                id="note"
                value={auditForm.note}
                onChange={(e) => setAuditForm({ ...auditForm, note: e.target.value })}
                placeholder="请输入审批备注"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAuditDialogOpen(false)}>
              取消
            </Button>
            <Button 
              onClick={handleAudit}
              disabled={!auditForm.action}
            >
              确认审批
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}