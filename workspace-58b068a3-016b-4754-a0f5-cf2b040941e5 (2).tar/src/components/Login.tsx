"use client"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Users, LogIn } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'

interface LoginProps {
  onLogin: (user: { id: string; name: string; role: string; studentId: string }) => void
}

export default function Login({ onLogin }: LoginProps) {
  const [studentId, setStudentId] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  // 模拟用户数据
  const mockUsers = [
    { id: '1', studentId: 'ADMIN001', name: '系统管理员', role: 'ADMIN', password: 'admin123' },
    { id: '2', studentId: '2021003', name: '王五', role: 'CLUB_MANAGER', password: 'student123' },
    { id: '3', studentId: '2021001', name: '张三', role: 'STAFF', password: 'student123' },
    { id: '4', studentId: '2021002', name: '李四', role: 'STUDENT', password: 'student123' }
  ]

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // 模拟登录验证
      const user = mockUsers.find(u => u.studentId === studentId && u.password === password)
      
      if (user) {
        toast({
          title: "登录成功",
          description: `欢迎回来，${user.name}！`,
        })
        
        onLogin({
          id: user.id,
          name: user.name,
          role: user.role,
          studentId: user.studentId
        })
      } else {
        toast({
          variant: "destructive",
          title: "登录失败",
          description: "学号或密码错误，请检查后重试",
        })
      }
    } catch (error) {
      console.error('登录失败:', error)
      toast({
        variant: "destructive",
        title: "登录失败",
        description: "系统异常，请稍后重试",
      })
    } finally {
      setLoading(false)
    }
  }

  const quickLogin = (user: typeof mockUsers[0]) => {
    setStudentId(user.studentId)
    setPassword(user.password)
  }

  const getRoleLabel = (role: string) => {
    const roleMap = {
      'ADMIN': '超级管理员',
      'CLUB_MANAGER': '社团社长',
      'STAFF': '社团干事',
      'STUDENT': '普通学生'
    }
    return roleMap[role as keyof typeof roleMap] || role
  }

  const getRoleBadgeVariant = (role: string) => {
    const variantMap = {
      'ADMIN': 'default',
      'CLUB_MANAGER': 'secondary',
      'STAFF': 'outline',
      'STUDENT': 'secondary'
    }
    return variantMap[role as keyof typeof variantMap] || 'secondary'
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="mx-auto h-12 w-12 flex items-center justify-center rounded-full bg-primary">
            <Users className="h-6 w-6 text-primary-foreground" />
          </div>
          <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
            社团管理系统
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            请使用您的学号和密码登录
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-center">用户登录</CardTitle>
            <CardDescription className="text-center">
              输入您的学号和密码以访问系统
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="studentId">学号</Label>
                  <Input
                    id="studentId"
                    type="text"
                    value={studentId}
                    onChange={(e) => setStudentId(e.target.value)}
                    placeholder="请输入学号"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="password">密码</Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="请输入密码"
                    required
                  />
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    登录中...
                  </div>
                ) : (
                  <div className="flex items-center">
                    <LogIn className="h-4 w-4 mr-2" />
                    登录
                  </div>
                )}
              </Button>
            </form>

            {/* 快速登录 */}
            <div className="mt-6 pt-6 border-t">
              <p className="text-sm text-gray-600 mb-3 text-center">
                快速登录（演示账号）
              </p>
              <div className="space-y-2">
                {mockUsers.map((user) => (
                  <Button
                    key={user.id}
                    variant="outline"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => quickLogin(user)}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span>{user.name} ({user.studentId})</span>
                      <Badge variant={getRoleBadgeVariant(user.role) as any}>
                        {getRoleLabel(user.role)}
                      </Badge>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}