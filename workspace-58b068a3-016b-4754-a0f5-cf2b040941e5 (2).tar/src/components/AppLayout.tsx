"use client"

import { useState, useEffect } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import Sidebar from '@/components/Sidebar'
import Login from '@/components/Login'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { LogOut, User, Settings } from 'lucide-react'

interface User {
  id: string
  name: string
  role: 'ADMIN' | 'CLUB_MANAGER' | 'STAFF' | 'STUDENT'
  studentId: string
}

interface AppLayoutProps {
  children: React.ReactNode
}

export default function AppLayout({ children }: AppLayoutProps) {
  const [user, setUser] = useState<User | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  // 页面加载时检查localStorage中的登录状态
  useEffect(() => {
    const savedUser = localStorage.getItem('clubUser')
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser)
        setUser(userData)
      } catch (error) {
        console.error('解析用户数据失败:', error)
        localStorage.removeItem('clubUser')
      }
    }
  }, [])

  const handleLogin = (userData: User) => {
    setUser(userData)
    localStorage.setItem('clubUser', JSON.stringify(userData))
    
    // 根据用户角色跳转到对应页面
    if (userData.role === 'ADMIN') {
      router.push('/dashboard')
    } else if (userData.role === 'CLUB_MANAGER') {
      router.push('/club-dashboard')
    } else if (userData.role === 'STAFF') {
      router.push('/club-dashboard')
    } else {
      router.push('/dashboard')
    }
  }

  const handleLogout = () => {
    setUser(null)
    localStorage.removeItem('clubUser')
    router.push('/')
  }

  // 如果用户未登录，显示登录页面
  if (!user) {
    return <Login onLogin={handleLogin} />
  }

  return (
    <div className="flex h-screen bg-background">
      {/* 固定侧边栏 */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-16'} transition-all duration-300 ease-in-out fixed left-0 top-0 h-full z-40 bg-card border-r`}>
        <Sidebar 
          user={user} 
          isOpen={sidebarOpen}
          onToggle={() => setSidebarOpen(!sidebarOpen)}
        />
      </div>

      {/* 主内容区域 */}
      <div className={`flex-1 flex flex-col transition-all duration-300 ease-in-out ${sidebarOpen ? 'ml-64' : 'ml-16'}`}>
        {/* 固定顶部导航栏 */}
        <header className="h-16 bg-card border-b px-6 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </Button>
            <h1 className="text-xl font-semibold">
              {user.role === 'ADMIN' ? '社团管理系统' : 
               user.role === 'CLUB_MANAGER' ? '社团管理' :
               user.role === 'STAFF' ? '社团管理' : '学生社团'}
            </h1>
          </div>

          {/* 用户菜单 */}
          <div className="flex items-center space-x-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.studentId}`} />
                    <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user.name}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user.studentId}
                    </p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {user.role === 'ADMIN' ? '超级管理员' : 
                       user.role === 'CLUB_MANAGER' ? '社团社长' :
                       user.role === 'STAFF' ? '社团干事' : '普通学生'}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>个人资料</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  <span>设置</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>退出登录</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* 可滚动的内容区域 */}
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  )
}