"use client"

import { useState } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Badge } from '@/components/ui/badge'
import { 
  LayoutDashboard,
  Building,
  Users,
  Calendar,
  CreditCard,
  FileText,
  Settings,
  Menu,
  Plus,
  Upload,
  UserPlus,
  LogOut
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface MenuItem {
  id: string
  label: string
  icon: React.ReactNode
  badge?: string
  path: string
}

interface SidebarProps {
  user: {
    id: string
    name: string
    role: 'ADMIN' | 'CLUB_MANAGER' | 'STAFF' | 'STUDENT'
    studentId: string
  }
  isOpen: boolean
  onToggle: () => void
}

const menuItems: Record<string, MenuItem[]> = {
  ADMIN: [
    {
      id: 'dashboard',
      label: '系统概览',
      icon: <LayoutDashboard className="h-4 w-4" />,
      path: '/dashboard'
    },
    {
      id: 'clubs',
      label: '社团管理',
      icon: <Building className="h-4 w-4" />,
      path: '/clubs'
    },
    {
      id: 'categories',
      label: '分类管理',
      icon: <Settings className="h-4 w-4" />,
      path: '/categories'
    },
    {
      id: 'members',
      label: '成员管理',
      icon: <Users className="h-4 w-4" />,
      badge: '3',
      path: '/members'
    },
    {
      id: 'transfers',
      label: '转社申请',
      icon: <Upload className="h-4 w-4" />,
      badge: '1',
      path: '/transfers'
    },
    {
      id: 'activities',
      label: '活动管理',
      icon: <Calendar className="h-4 w-4" />,
      badge: '2',
      path: '/activities'
    },
    {
      id: 'finance',
      label: '财务管理',
      icon: <CreditCard className="h-4 w-4" />,
      path: '/finance'
    },
    {
      id: 'resources',
      label: '物资管理',
      icon: <FileText className="h-4 w-4" />,
      badge: '1',
      path: '/resources'
    }
  ],
  CLUB_MANAGER: [
    {
      id: 'dashboard',
      label: '社团概览',
      icon: <LayoutDashboard className="h-4 w-4" />,
      path: '/club-dashboard'
    },
    {
      id: 'members',
      label: '成员管理',
      icon: <Users className="h-4 w-4" />,
      badge: '3',
      path: '/members'
    },
    {
      id: 'transfers',
      label: '转社申请',
      icon: <Upload className="h-4 w-4" />,
      badge: '1'
    },
    {
      id: 'activities',
      label: '活动管理',
      icon: <Calendar className="h-4 w-4" />
    },
    {
      id: 'finance',
      label: '财务管理',
      icon: <CreditCard className="h-4 w-4" />
    },
    {
      id: 'resources',
      label: '物资申请',
      icon: <FileText className="h-4 w-4" />
    }
  ],
  STAFF: [
    {
      id: 'dashboard',
      label: '工作台',
      icon: <LayoutDashboard className="h-4 w-4" />
    },
    {
      id: 'members',
      label: '成员审核',
      icon: <UserPlus className="h-4 w-4" />,
      badge: '3'
    },
    {
      id: 'transfers',
      label: '转社审批',
      icon: <Upload className="h-4 w-4" />,
      badge: '1'
    },
    {
      id: 'activities',
      label: '活动申请',
      icon: <Plus className="h-4 w-4" />
    },
    {
      id: 'resources',
      label: '物资申请',
      icon: <FileText className="h-4 w-4" />
    }
  ],
  STUDENT: [
    {
      id: 'dashboard',
      label: '我的社团',
      icon: <LayoutDashboard className="h-4 w-4" />
    },
    {
      id: 'activities',
      label: '活动报名',
      icon: <Calendar className="h-4 w-4" />
    },
    {
      id: 'transfer',
      label: '转社申请',
      icon: <Upload className="h-4 w-4" />
    }
  ]
}

export default function Sidebar({ user, isOpen, onToggle }: SidebarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const router = useRouter()
  const pathname = usePathname()
  const items = menuItems[user.role] || []

  const handleNavigation = (path: string) => {
    router.push(path)
  }

  const getRoleLabel = (role: string) => {
    const roleMap = {
      'ADMIN': '超级管理员',
      'CLUB_MANAGER': '社团社长',
      'STAFF': '社团干事',
      'STUDENT': '普通学生'
    }
    return roleMap[role as keyof typeof roleMap] || role
  }

  const getRoleBadgeVariant = (role: string) => {
    const variantMap = {
      'ADMIN': 'default',
      'CLUB_MANAGER': 'secondary',
      'STAFF': 'outline',
      'STUDENT': 'secondary'
    }
    return variantMap[role as keyof typeof variantMap] || 'secondary'
  }

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden border-r bg-muted/40 md:block h-full">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
            <div className="flex items-center gap-2 font-semibold">
              <span className="">社团管理系统</span>
            </div>
          </div>
          
          <div className="flex-1">
            <nav className="grid items-start px-2 text-sm font-medium lg:px-4">
              {items.map((item) => (
                <Button
                  key={item.id}
                  variant={pathname === item.path ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-2",
                    pathname === item.path && "bg-muted"
                  )}
                  onClick={() => handleNavigation(item.path)}
                >
                  {item.icon}
                  {isOpen && (
                    <>
                      {item.label}
                      {item.badge && (
                        <Badge variant="secondary" className="ml-auto">
                          {item.badge}
                        </Badge>
                      )}
                    </>
                  )}
                  {!isOpen && item.badge && (
                    <Badge variant="secondary" className="ml-auto">
                      {item.badge}
                    </Badge>
                  )}
                </Button>
              ))}
            </nav>
          </div>

          <div className="mt-auto p-4 border-t">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex-1">
                <p className="text-sm font-medium">{user.name}</p>
                <Badge variant={getRoleBadgeVariant(user.role) as any} className="text-xs">
                  {getRoleLabel(user.role)}
                </Badge>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
        <SheetTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="shrink-0 md:hidden"
          >
            <Menu className="h-5 w-5" />
            <span className="sr-only">切换导航菜单</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="flex flex-col p-0">
          <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
            <div className="flex items-center gap-2 font-semibold">
              <span className="">社团管理系统</span>
            </div>
          </div>
          
          <div className="flex-1">
            <nav className="grid items-start px-2 text-sm font-medium lg:px-4">
              {items.map((item) => (
                <Button
                  key={item.id}
                  variant={pathname === item.path ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-2",
                    pathname === item.path && "bg-muted"
                  )}
                  onClick={() => {
                    handleNavigation(item.path)
                    setIsMobileMenuOpen(false)
                  }}
                >
                  {item.icon}
                  {item.label}
                  {item.badge && (
                    <Badge variant="secondary" className="ml-auto">
                      {item.badge}
                    </Badge>
                  )}
                </Button>
              ))}
            </nav>
          </div>

          <div className="mt-auto p-4 border-t">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex-1">
                <p className="text-sm font-medium">{user.name}</p>
                <Badge variant={getRoleBadgeVariant(user.role) as any} className="text-xs">
                  {getRoleLabel(user.role)}
                </Badge>
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}