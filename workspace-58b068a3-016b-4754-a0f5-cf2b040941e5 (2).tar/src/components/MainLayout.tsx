"use client"

import { useState, useEffect } from 'react'
import Sidebar from '@/components/Sidebar'
import Login from '@/components/Login'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Users, 
  Calendar, 
  DollarSign, 
  CheckCircle, 
  Clock, 
  TrendingUp,
  Plus,
  FileText,
  CreditCard,
  UserPlus,
  Menu
} from 'lucide-react'
import ClubManagement from '@/components/ClubManagement'
import CategoryManagement from '@/components/CategoryManagement'
import MemberManagement from '@/components/MemberManagement'
import TransferManagement from '@/components/TransferManagement'

interface User {
  id: string
  name: string
  role: 'ADMIN' | 'CLUB_MANAGER' | 'STAFF' | 'STUDENT'
  studentId: string
}

interface DashboardStats {
  totalClubs: number
  totalStudents: number
  todayActivities: number
  pendingApprovals: number
}

interface Category {
  name: string
  count: number
  percentage: number
}

interface ActiveClub {
  name: string
  activities: number
}

interface Announcement {
  id: string
  title: string
  content: string
  type: 'URGENT' | 'GENERAL' | 'SYSTEM'
  isPinned: boolean
  createdAt: string
}

interface ApiResponse {
  stats: DashboardStats
  categories: Category[]
  activeClubs: ActiveClub[]
  announcements: Announcement[]
}

export default function MainLayout() {
  const [user, setUser] = useState<User | null>(null)
  const [currentPath, setCurrentPath] = useState('dashboard')
  const [data, setData] = useState<ApiResponse | null>(null)
  const [loading, setLoading] = useState(true)

  // 页面加载时检查localStorage中的登录状态
  useEffect(() => {
    const savedUser = localStorage.getItem('clubUser')
    if (savedUser) {
      try {
        const userData = JSON.parse(savedUser)
        setUser(userData)
        setCurrentPath('dashboard')
        fetchDashboardData()
      } catch (error) {
        console.error('解析用户数据失败:', error)
        localStorage.removeItem('clubUser')
      }
    }
    setLoading(false)
  }, [])

  const todoItems = [
    { type: '入社申请', count: 3, color: 'bg-blue-500' },
    { type: '转社申请', count: 1, color: 'bg-orange-500' },
    { type: '活动审批', count: 2, color: 'bg-green-500' },
    { type: '物资申请', count: 1, color: 'bg-purple-500' }
  ]

  const handleLogin = (userData: User) => {
    setUser(userData)
    localStorage.setItem('clubUser', JSON.stringify(userData))
    setCurrentPath('dashboard')
    fetchDashboardData()
  }

  const handleLogout = () => {
    setUser(null)
    localStorage.removeItem('clubUser')
    setCurrentPath('dashboard')
    setData(null)
  }

  const fetchDashboardData = async () => {
    try {
      const response = await fetch('/api')
      if (response.ok) {
        const result = await response.json()
        
        // 计算分类百分比
        const totalClubs = result.categories.reduce((sum: number, cat: Category) => sum + cat.count, 0)
        const categoriesWithPercentage = result.categories.map((cat: Category) => ({
          ...cat,
          percentage: totalClubs > 0 ? Math.round((cat.count / totalClubs) * 100) : 0
        }))

        setData({
          ...result,
          categories: categoriesWithPercentage
        })
      }
    } catch (error) {
      console.error('获取数据失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))
    
    if (diffInHours < 1) return '刚刚'
    if (diffInHours < 24) return `${diffInHours}小时前`
    if (diffInHours < 48) return '1天前'
    return `${Math.floor(diffInHours / 24)}天前`
  }

  // 如果用户未登录，显示登录页面
  if (!user) {
    return <Login onLogin={handleLogin} />
  }

  // 根据用户角色渲染不同的仪表盘
  const renderDashboard = () => {
    if (user.role === 'ADMIN') {
      return (
        <div className="space-y-6">
          {/* 统计卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">全校社团总数</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{loading ? '...' : data?.stats.totalClubs || 0}</div>
                <p className="text-xs text-muted-foreground">活跃社团 {data?.stats.totalClubs || 0} 个</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">注册学生总数</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{loading ? '...' : data?.stats.totalStudents || 0}</div>
                <p className="text-xs text-muted-foreground">本学期新增 156 人</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">今日活动数</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{loading ? '...' : data?.stats.todayActivities || 0}</div>
                <p className="text-xs text-muted-foreground">本周累计 24 场</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">待办审批</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{loading ? '...' : data?.stats.pendingApprovals || 0}</div>
                <p className="text-xs text-muted-foreground">需要处理</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 社团分类占比 */}
            <Card>
              <CardHeader>
                <CardTitle>社团分类分布</CardTitle>
                <CardDescription>各类别社团数量占比</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {loading ? (
                    <div className="animate-pulse space-y-3">
                      {[1, 2, 3, 4].map((i) => (
                        <div key={i} className="h-4 bg-gray-200 rounded"></div>
                      ))}
                    </div>
                  ) : (
                    data?.categories.map((category, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded-full bg-${['blue', 'green', 'orange', 'purple'][index % 4]}-500`} />
                          <span className="text-sm font-medium">{category.name}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-muted-foreground">{category.count}个</span>
                          <Badge variant="secondary">{category.percentage}%</Badge>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {/* 活跃度排行 */}
            <Card>
              <CardHeader>
                <CardTitle>社团活跃度排行</CardTitle>
                <CardDescription>本学期举办活动次数 Top 10</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {loading ? (
                    <div className="animate-pulse space-y-3">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <div key={i} className="h-4 bg-gray-200 rounded"></div>
                      ))}
                    </div>
                  ) : (
                    data?.activeClubs.map((club, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-bold">
                            {index + 1}
                          </div>
                          <span className="text-sm font-medium">{club.name}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <TrendingUp className="h-4 w-4 text-green-500" />
                          <span className="text-sm font-medium">{club.activities}</span>
                          <span className="text-xs text-muted-foreground">场活动</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* 系统公告 */}
          <Card>
            <CardHeader>
              <CardTitle>系统公告</CardTitle>
              <CardDescription>重要通知和公告</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {loading ? (
                  <div className="animate-pulse space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-4 bg-gray-200 rounded"></div>
                    ))}
                  </div>
                ) : (
                  data?.announcements.map((announcement, index) => (
                    <div key={index} className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h4 className="text-sm font-medium">{announcement.title}</h4>
                          <Badge variant={announcement.type === 'URGENT' ? 'destructive' : 'secondary'}>
                            {announcement.type === 'URGENT' ? '紧急' : announcement.type === 'SYSTEM' ? '系统' : '通用'}
                          </Badge>
                          {announcement.isPinned && <Badge variant="outline">置顶</Badge>}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">{formatTimeAgo(announcement.createdAt)}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )
    } else if (user.role === 'CLUB_MANAGER') {
      return (
        <div className="space-y-6">
          {/* 本社团概况 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">成员总数</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">45</div>
                <p className="text-xs text-muted-foreground">本月新增 5 人</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">当前经费</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">¥8,500</div>
                <p className="text-xs text-muted-foreground">本学期收入 ¥12,000</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">社团评分</CardTitle>
                <CheckCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4.8</div>
                <p className="text-xs text-muted-foreground">五星社团</p>
              </CardContent>
            </Card>
          </div>

          {/* 待办事项 */}
          <Card>
            <CardHeader>
              <CardTitle>待办事项</CardTitle>
              <CardDescription>需要处理的申请和任务</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {todoItems.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center space-x-3">
                      <div className={`w-2 h-2 rounded-full ${item.color}`} />
                      <span className="text-sm font-medium">{item.type}</span>
                    </div>
                    <Badge variant="secondary">{item.count} 条待处理</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 快捷入口 */}
          <Card>
            <CardHeader>
              <CardTitle>快捷操作</CardTitle>
              <CardDescription>常用功能入口</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Button className="h-16 flex flex-col space-y-2">
                  <Plus className="h-5 w-5" />
                  <span className="text-xs">发布活动</span>
                </Button>
                <Button variant="outline" className="h-16 flex flex-col space-y-2">
                  <CreditCard className="h-5 w-5" />
                  <span className="text-xs">财务记账</span>
                </Button>
                <Button variant="outline" className="h-16 flex flex-col space-y-2">
                  <UserPlus className="h-5 w-5" />
                  <span className="text-xs">成员导入</span>
                </Button>
                <Button variant="outline" className="h-16 flex flex-col space-y-2">
                  <FileText className="h-5 w-5" />
                  <span className="text-xs">申请物资</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    } else if (user.role === 'STAFF') {
      return (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>干事工作台</CardTitle>
              <CardDescription>管理社团日常事务，协助社长处理申请</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">待审核成员</CardTitle>
                    <UserPlus className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">3</div>
                    <p className="text-xs text-muted-foreground">需要审核</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">活动申请</CardTitle>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">2</div>
                    <p className="text-xs text-muted-foreground">待处理</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">物资申请</CardTitle>
                    <FileText className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">1</div>
                    <p className="text-xs text-muted-foreground">待审批</p>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    } else {
      // STUDENT
      return (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>我的社团</CardTitle>
              <CardDescription>查看我的社团信息和活动</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <h3 className="text-lg font-medium text-muted-foreground">暂未加入社团</h3>
                <p className="text-sm text-muted-foreground mt-2">您可以浏览活动并申请加入感兴趣的社团</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )
    }
  }

  // 根据路径渲染内容
  const renderContent = () => {
    switch (currentPath) {
      case 'dashboard':
        return renderDashboard()
      case 'clubs':
        if (user.role === 'ADMIN') {
          return <ClubManagement />
        }
        return <div className="text-center py-12"><h3 className="text-lg font-medium text-muted-foreground">功能开发中...</h3></div>
      case 'categories':
        if (user.role === 'ADMIN') {
          return <CategoryManagement />
        }
        return <div className="text-center py-12"><h3 className="text-lg font-medium text-muted-foreground">功能开发中...</h3></div>
      case 'members':
        if (user.role === 'ADMIN' || user.role === 'CLUB_MANAGER') {
          return <MemberManagement />
        } else if (user.role === 'STAFF') {
          return <MemberManagement />
        }
        return <div className="text-center py-12"><h3 className="text-lg font-medium text-muted-foreground">功能开发中...</h3></div>
      case 'transfers':
        if (user.role === 'ADMIN' || user.role === 'CLUB_MANAGER' || user.role === 'STAFF') {
          return <TransferManagement />
        }
        return <div className="text-center py-12"><h3 className="text-lg font-medium text-muted-foreground">功能开发中...</h3></div>
      default:
        return <div className="text-center py-12"><h3 className="text-lg font-medium text-muted-foreground">功能开发中...</h3></div>
    }
  }

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[220px_1fr] lg:grid-cols-[280px_1fr]">
      <Sidebar
        currentPath={currentPath}
        onNavigate={setCurrentPath}
        userRole={user.role}
        userName={user.name}
        onLogout={handleLogout}
      />
      <div className="flex flex-col">
        <header className="flex h-14 items-center gap-4 border-b bg-muted/40 px-4 lg:h-[60px] lg:px-6">
          <div className="md:hidden">
            <Button
              variant="outline"
              size="icon"
              className="shrink-0"
              onClick={() => {}}
            >
              <Menu className="h-5 w-5" />
              <span className="sr-only">切换导航菜单</span>
            </Button>
          </div>
          <div className="w-full flex-1">
            <h1 className="text-lg font-semibold md:text-2xl">
              {user.role === 'ADMIN' && '系统管理'}
              {user.role === 'CLUB_MANAGER' && '社团管理'}
              {user.role === 'STAFF' && '干事工作台'}
              {user.role === 'STUDENT' && '学生中心'}
            </h1>
          </div>
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  )
}