"use client"

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Plus, Edit, Eye, Search, Filter, UserPlus, Crown, Users } from 'lucide-react'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { useToast } from '@/hooks/use-toast'

interface Club {
  id: string
  name: string
  description?: string
  logo?: string
  status: string
  balance: number
  starRating: number
  memberCount: number
  establishedAt?: string
  category: {
    id: string
    name: string
  }
  manager?: {
    id: string
    name: string
    studentId: string
  }
}

interface Category {
  id: string
  name: string
  description?: string
  sort: number
  clubCount: number
}

interface User {
  id: string
  studentId: string
  name: string
  email: string
  role: string
}

export default function ClubManagement() {
  const [clubs, setClubs] = useState<Club[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedStatus, setSelectedStatus] = useState<string>('all')
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [pageSize] = useState(10)
  
  // Dialog states
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedClub, setSelectedClub] = useState<Club | null>(null)
  const [activeEditTab, setActiveEditTab] = useState('basic')
  
  // 成员管理状态
  const [members, setMembers] = useState<any[]>([])
  const [memberLoading, setMemberLoading] = useState(false)
  const [memberSearchTerm, setMemberSearchTerm] = useState('')
  const [memberRoleFilter, setMemberRoleFilter] = useState('all')
  const [memberCurrentPage, setMemberCurrentPage] = useState(1)
  const [memberTotalPages, setMemberTotalPages] = useState(1)
  const [memberPageSize] = useState(10)
  const [isSetManagerDialogOpen, setIsSetManagerDialogOpen] = useState(false)
  const [isRemoveManagerDialogOpen, setIsRemoveManagerDialogOpen] = useState(false)
  const [selectedMember, setSelectedMember] = useState<any>(null)
  
  // Form states
  const [newClub, setNewClub] = useState({
    name: '',
    description: '',
    categoryId: '',
    managerId: '',
    managerName: '',
    managerStudentId: '',
    managerEmail: '',
    logo: null as File | null
  })
  
  // 社长选择模式
  const [managerSelectMode, setManagerSelectMode] = useState<'select' | 'create'>('select')
  const [managerSearchTerm, setManagerSearchTerm] = useState('')
  const [filteredUsers, setFilteredUsers] = useState<User[]>([])
  
  const { toast } = useToast()
  const searchTimeoutRef = useRef<NodeJS.Timeout>()

  // 防抖搜索
  useEffect(() => {
    if (searchTimeoutRef.current) {
      clearTimeout(searchTimeoutRef.current)
    }
    
    searchTimeoutRef.current = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm)
      setCurrentPage(1)
    }, 500)
    
    return () => {
      if (searchTimeoutRef.current) {
        clearTimeout(searchTimeoutRef.current)
      }
    }
  }, [searchTerm])

  useEffect(() => {
    fetchClubs()
    fetchCategories()
    fetchUsers()
  }, [debouncedSearchTerm, selectedCategory, selectedStatus, currentPage])

  // 监听成员管理相关状态变化
  useEffect(() => {
    if (selectedClub && isEditDialogOpen) {
      fetchMembers(selectedClub.id)
    }
  }, [memberSearchTerm, memberRoleFilter, memberCurrentPage])

  const fetchClubs = async () => {
    try {
      setLoading(true)
      const params = new URLSearchParams()
      if (selectedCategory && selectedCategory !== 'all') params.append('categoryId', selectedCategory)
      if (selectedStatus && selectedStatus !== 'all') params.append('status', selectedStatus)
      if (debouncedSearchTerm) params.append('search', debouncedSearchTerm)
      params.append('page', currentPage.toString())
      params.append('pageSize', pageSize.toString())
      
      const response = await fetch(`/api/clubs?${params.toString()}`)
      if (response.ok) {
        const data = await response.json()
        setClubs(data.clubs || [])
        setTotalPages(data.totalPages || 1)
      }
    } catch (error) {
      console.error('获取社团列表失败:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/categories')
      if (response.ok) {
        const data = await response.json()
        setCategories(data)
      }
    } catch (error) {
      console.error('获取分类列表失败:', error)
    }
  }

  const fetchUsers = async () => {
    try {
      const response = await fetch('/api/users?availableForClub=true')
      if (response.ok) {
        const data = await response.json()
        setUsers(data.users || [])
      }
    } catch (error) {
      console.error('获取用户列表失败:', error)
    }
  }

  const handleCreateClub = async () => {
    try {
      const existingClub = clubs.find(c => c.name.toLowerCase() === newClub.name.toLowerCase())
      if (existingClub) {
        toast({
          variant: "destructive",
          title: "创建失败",
          description: "社团名称已存在",
        })
        return
      }

      let managerId = newClub.managerId

      if (managerSelectMode === 'create') {
        const existingStudentId = users.find(u => u.studentId === newClub.managerStudentId)
        if (existingStudentId) {
          toast({
            variant: "destructive",
            title: "创建失败",
            description: "该学号已被使用",
          })
          return
        }

        const existingEmail = users.find(u => u.email === newClub.managerEmail)
        if (existingEmail) {
          toast({
            variant: "destructive",
            title: "创建失败",
            description: "该邮箱已被使用",
          })
          return
        }

        const createUserResponse = await fetch('/api/users', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            studentId: newClub.managerStudentId,
            name: newClub.managerName,
            email: newClub.managerEmail,
            role: 'CLUB_MANAGER'
          }),
        })

        if (!createUserResponse.ok) {
          const error = await createUserResponse.json()
          toast({
            variant: "destructive",
            title: "创建失败",
            description: error.error || '创建社长账号失败',
          })
          return
        }

        const userData = await createUserResponse.json()
        managerId = userData.user.id
      }

      const formData = new FormData()
      formData.append('name', newClub.name)
      formData.append('description', newClub.description)
      formData.append('categoryId', newClub.categoryId)
      formData.append('managerId', managerId)
      formData.append('status', 'ACTIVE')
      if (newClub.logo) {
        formData.append('logo', newClub.logo)
      }

      const response = await fetch('/api/clubs', {
        method: 'POST',
        body: formData,
      })

      if (response.ok) {
        setIsCreateDialogOpen(false)
        setNewClub({ 
          name: '', 
          description: '', 
          categoryId: '', 
          managerId: '',
          managerName: '',
          managerStudentId: '',
          managerEmail: '',
          logo: null 
        })
        setManagerSelectMode('select')
        setManagerSearchTerm('')
        fetchClubs()
        
        toast({
          title: "创建成功",
          description: managerSelectMode === 'create' 
            ? "社团创建成功，新社长账号已创建并邮件通知" 
            : "社团创建成功，已设置社长",
        })
      } else {
        const error = await response.json()
        toast({
          variant: "destructive",
          title: "创建失败",
          description: error.error || '创建失败，请检查输入信息',
        })
      }
    } catch (error) {
      console.error('创建社团失败:', error)
      toast({
        variant: "destructive",
        title: "创建失败",
        description: "网络错误，请稍后重试",
      })
    }
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      'PENDING': { label: '待审核', variant: 'secondary' as const },
      'ACTIVE': { label: '正常', variant: 'default' as const },
      'SUSPENDED': { label: '整改中', variant: 'destructive' as const },
      'CLOSED': { label: '已注销', variant: 'outline' as const }
    }
    return statusMap[status as keyof typeof statusMap] || { label: status, variant: 'secondary' as const }
  }

  const openViewDialog = (club: Club) => {
    setSelectedClub(club)
    setIsViewDialogOpen(true)
  }

  const openEditDialog = async (club: Club) => {
    setSelectedClub(club)
    setActiveEditTab('basic')
    setIsEditDialogOpen(true)
    // 加载成员数据
    await fetchMembers(club.id)
  }

  const fetchMembers = async (clubId: string) => {
    try {
      setMemberLoading(true)
      const params = new URLSearchParams()
      params.append('clubId', clubId)
      if (memberSearchTerm) params.append('search', memberSearchTerm)
      if (memberRoleFilter && memberRoleFilter !== 'all') params.append('role', memberRoleFilter)
      params.append('page', memberCurrentPage.toString())
      params.append('pageSize', memberPageSize.toString())
      
      const response = await fetch(`/api/members?${params.toString()}`)
      if (response.ok) {
        const data = await response.json()
        setMembers(data.members || [])
        setMemberTotalPages(data.totalPages || 1)
      }
    } catch (error) {
      console.error('获取成员列表失败:', error)
      toast({
        variant: "destructive",
        title: "获取失败",
        description: "无法加载成员数据",
      })
    } finally {
      setMemberLoading(false)
    }
  }

  const resetFilters = () => {
    setSearchTerm('')
    setSelectedCategory('all')
    setSelectedStatus('all')
    setCurrentPage(1)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">社团管理</h2>
          <p className="text-muted-foreground">管理全校社团信息</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              新建社团
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>创建新社团</DialogTitle>
              <DialogDescription>
                填写社团基本信息，创建后社团将直接生效。
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">社团名称</Label>
                  <Input
                    id="name"
                    value={newClub.name}
                    onChange={(e) => setNewClub({ ...newClub, name: e.target.value })}
                    placeholder="请输入社团名称"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="categoryId">所属分类</Label>
                  <Select value={newClub.categoryId} onValueChange={(value) => setNewClub({ ...newClub, categoryId: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="选择分类" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">社团简介</Label>
                <Textarea
                  id="description"
                  value={newClub.description}
                  onChange={(e) => setNewClub({ ...newClub, description: e.target.value })}
                  placeholder="请输入社团简介"
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <Label>社长设置</Label>
                <div className="space-y-3">
                  <div className="flex space-x-2">
                    <Button
                      type="button"
                      variant={managerSelectMode === 'select' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setManagerSelectMode('select')}
                    >
                      选择现有用户
                    </Button>
                    <Button
                      type="button"
                      variant={managerSelectMode === 'create' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setManagerSelectMode('create')}
                    >
                      新建社长
                    </Button>
                  </div>

                  {managerSelectMode === 'select' && (
                    <div>
                      <Label htmlFor="managerSearch">搜索用户</Label>
                      <div className="relative">
                        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="managerSearch"
                          placeholder="搜索姓名、学号或邮箱"
                          value={managerSearchTerm}
                          onChange={(e) => setManagerSearchTerm(e.target.value)}
                          className="pl-8"
                        />
                      </div>
                      
                      <div className="mt-2 max-h-40 overflow-y-auto border rounded-md">
                        {filteredUsers.length > 0 ? (
                          filteredUsers.map((user) => (
                            <div
                              key={user.id}
                              className={`p-2 hover:bg-gray-50 cursor-pointer flex items-center space-x-3 border-b last:border-b-0 ${
                                newClub.managerId === user.id ? 'bg-blue-50' : ''
                              }`}
                              onClick={() => setNewClub({ ...newClub, managerId: user.id })}
                            >
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.studentId}`} />
                                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900 truncate">
                                  {user.name}
                                </p>
                                <p className="text-sm text-gray-500 truncate">
                                  {user.studentId} • {user.email}
                                </p>
                              </div>
                              {newClub.managerId === user.id && (
                                <Crown className="h-4 w-4 text-yellow-500" />
                              )}
                            </div>
                          ))
                        ) : (
                          <div className="p-4 text-center text-sm text-gray-500">
                            未找到匹配的用户
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {managerSelectMode === 'create' && (
                    <div className="grid grid-cols-1 gap-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="managerName">社长姓名</Label>
                          <Input
                            id="managerName"
                            value={newClub.managerName}
                            onChange={(e) => setNewClub({ ...newClub, managerName: e.target.value })}
                            placeholder="请输入社长姓名"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="managerStudentId">社长学号</Label>
                          <Input
                            id="managerStudentId"
                            value={newClub.managerStudentId}
                            onChange={(e) => setNewClub({ ...newClub, managerStudentId: e.target.value })}
                            placeholder="请输入社长学号"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="managerEmail">社长邮箱</Label>
                        <Input
                          id="managerEmail"
                          type="email"
                          value={newClub.managerEmail}
                          onChange={(e) => setNewClub({ ...newClub, managerEmail: e.target.value })}
                          placeholder="请输入社长邮箱"
                        />
                      </div>
                      <div className="text-sm text-gray-500 bg-blue-50 p-3 rounded">
                        💡 系统将自动创建社长账号并发送邮件通知登录密码
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="logo">社团Logo</Label>
                <Input
                  id="logo"
                  type="file"
                  accept="image/*"
                  onChange={(e) => setNewClub({ ...newClub, logo: e.target.files?.[0] || null })}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                取消
              </Button>
              <Button onClick={handleCreateClub}>
                创建
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* 筛选器 */}
      <Card>
        <CardHeader>
          <CardTitle>筛选条件</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="search">搜索</Label>
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="search"
                  placeholder="搜索社团名称或简介"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onBlur={() => setDebouncedSearchTerm(searchTerm)}
                  className="pl-8"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="category">分类</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="选择分类" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部分类</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name} ({category.clubCount})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="status">状态</Label>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="选择状态" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部状态</SelectItem>
                  <SelectItem value="PENDING">待审核</SelectItem>
                  <SelectItem value="ACTIVE">正常</SelectItem>
                  <SelectItem value="SUSPENDED">整改中</SelectItem>
                  <SelectItem value="CLOSED">已注销</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button variant="outline" onClick={resetFilters}>
                <Filter className="h-4 w-4 mr-2" />
                重置筛选
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 社团列表 */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>社团列表</CardTitle>
            <CardDescription>共找到 {clubs.length} 个社团</CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">
              第 {currentPage} / {totalPages} 页
            </span>
            <div className="flex space-x-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
              >
                上一页
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
              >
                下一页
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="animate-pulse space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-16 bg-gray-200 rounded"></div>
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>社团名称</TableHead>
                  <TableHead>分类</TableHead>
                  <TableHead>社长</TableHead>
                  <TableHead>成员数</TableHead>
                  <TableHead>经费</TableHead>
                  <TableHead>评分</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clubs.map((club) => (
                  <TableRow key={club.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        {club.logo && (
                          <img
                            src={club.logo}
                            alt={club.name}
                            className="w-8 h-8 rounded object-cover"
                          />
                        )}
                        <div>
                          <div className="font-medium">{club.name}</div>
                          {club.description && (
                            <div className="text-sm text-muted-foreground truncate max-w-xs">
                              {club.description}
                            </div>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{club.category.name}</Badge>
                    </TableCell>
                    <TableCell>
                      {club.manager ? (
                        <div>
                          <div className="font-medium">{club.manager.name}</div>
                          <div className="text-sm text-muted-foreground">{club.manager.studentId}</div>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">未设置</span>
                      )}
                    </TableCell>
                    <TableCell>{club.memberCount}</TableCell>
                    <TableCell>¥{club.balance.toLocaleString()}</TableCell>
                    <TableCell>⭐ {club.starRating}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusBadge(club.status).variant}>
                        {getStatusBadge(club.status).label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openViewDialog(club)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openEditDialog(club)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* 查看社团详情对话框 */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>社团详情</DialogTitle>
            <DialogDescription>查看社团的详细信息</DialogDescription>
          </DialogHeader>
          {selectedClub && (
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                {selectedClub.logo && (
                  <img
                    src={selectedClub.logo}
                    alt={selectedClub.name}
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                )}
                <div>
                  <h3 className="text-xl font-bold">{selectedClub.name}</h3>
                  <Badge variant={getStatusBadge(selectedClub.status).variant} className="mt-2">
                    {getStatusBadge(selectedClub.status).label}
                  </Badge>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-2">基本信息</h4>
                  <div className="space-y-2 text-sm">
                    <div><span className="text-muted-foreground">分类：</span>{selectedClub.category.name}</div>
                    <div><span className="text-muted-foreground">成员数：</span>{selectedClub.memberCount}</div>
                    <div><span className="text-muted-foreground">经费：</span>¥{selectedClub.balance.toLocaleString()}</div>
                    <div><span className="text-muted-foreground">评分：</span>⭐ {selectedClub.starRating}</div>
                    {selectedClub.establishedAt && (
                      <div><span className="text-muted-foreground">成立时间：</span>{new Date(selectedClub.establishedAt).toLocaleDateString()}</div>
                    )}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">社长信息</h4>
                  {selectedClub.manager ? (
                    <div className="space-y-2 text-sm">
                      <div><span className="text-muted-foreground">姓名：</span>{selectedClub.manager.name}</div>
                      <div><span className="text-muted-foreground">学号：</span>{selectedClub.manager.studentId}</div>
                    </div>
                  ) : (
                    <div className="text-sm text-muted-foreground">未设置社长</div>
                  )}
                </div>
              </div>
              
              {selectedClub.description && (
                <div>
                  <h4 className="font-medium mb-2">社团简介</h4>
                  <p className="text-sm text-muted-foreground">{selectedClub.description}</p>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setIsViewDialogOpen(false)}>
              关闭
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 编辑社团对话框 */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>编辑社团</DialogTitle>
            <DialogDescription>修改社团信息和成员管理</DialogDescription>
          </DialogHeader>
          {selectedClub && (
            <Tabs value={activeEditTab} onValueChange={setActiveEditTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="basic" className="flex-1">基础信息</TabsTrigger>
                <TabsTrigger value="logo" className="flex-1">Logo管理</TabsTrigger>
                <TabsTrigger value="members" className="flex-1">成员管理</TabsTrigger>
              </TabsList>
              
              <TabsContent value="basic" className="space-y-4 mt-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-name">社团名称</Label>
                    <Input
                      id="edit-name"
                      defaultValue={selectedClub.name}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-categoryId">所属分类</Label>
                    <Select defaultValue={selectedClub.category.id}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.id} value={category.id}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-description">社团简介</Label>
                  <Textarea
                    id="edit-description"
                    defaultValue={selectedClub.description || ''}
                    rows={4}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-status">社团状态</Label>
                  <Select defaultValue={selectedClub.status}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACTIVE">正常</SelectItem>
                      <SelectItem value="SUSPENDED">整改中</SelectItem>
                      <SelectItem value="CLOSED">已注销</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>社长信息</Label>
                  <div className="p-3 bg-gray-50 rounded-md">
                    {selectedClub.manager ? (
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedClub.manager.studentId}`} />
                          <AvatarFallback>{selectedClub.manager.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{selectedClub.manager.name}</div>
                          <div className="text-sm text-muted-foreground">{selectedClub.manager.studentId}</div>
                        </div>
                        <Crown className="h-5 w-5 text-yellow-500" />
                      </div>
                    ) : (
                      <div className="text-sm text-muted-foreground">未设置社长</div>
                    )}
                    <div className="text-xs text-gray-500 mt-2">
                      💡 社长信息不可在此处修改，如需更换社长请在成员管理中操作
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="logo" className="space-y-4 mt-6">
                <div className="text-center">
                  {selectedClub.logo && (
                    <img
                      src={selectedClub.logo}
                      alt={selectedClub.name}
                      className="w-32 h-32 rounded-lg object-cover mx-auto mb-4"
                    />
                  )}
                  <div>
                    <h4 className="font-medium">Logo管理</h4>
                    <p>Logo管理功能正在开发中...</p>
                  </div>
                  <div>
                    <Input
                      type="file"
                      accept="image/*"
                      className="mx-auto max-w-xs"
                    />
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="members" className="space-y-4 mt-6">
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="member-search">搜索成员</Label>
                      <div className="relative">
                        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="member-search"
                          placeholder="搜索姓名、学号或邮箱"
                          value={memberSearchTerm}
                          onChange={(e) => setMemberSearchTerm(e.target.value)}
                          className="pl-8 max-w-xs"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="member-role">角色筛选</Label>
                      <Select value={memberRoleFilter} onValueChange={setMemberRoleFilter}>
                        <SelectTrigger>
                          <SelectValue placeholder="选择角色" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">全部角色</SelectItem>
                          <SelectItem value="MEMBER">普通会员</SelectItem>
                          <SelectItem value="STAFF">干事</SelectItem>
                          <SelectItem value="MANAGER">社长</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-end">
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          setMemberSearchTerm('')
                          setMemberRoleFilter('all')
                          setMemberCurrentPage(1)
                        }}
                      >
                        <Filter className="h-4 w-4 mr-2" />
                        重置筛选
                      </Button>
                    </div>
                  </div>

                  <div className="border rounded-lg">
                    <div className="overflow-x-auto overflow-y-auto" style={{ maxHeight: '400px' }}>
                      <div className="min-w-[900px]">
                        <Table className="w-full table-fixed">
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-[300px] px-3">成员信息</TableHead>
                              <TableHead className="w-[100px] px-3">角色</TableHead>
                              <TableHead className="w-[100px] px-3">状态</TableHead>
                              <TableHead className="w-[120px] px-3">加入时间</TableHead>
                              <TableHead className="w-[150px] px-3">操作</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {memberLoading ? (
                              <TableRow>
                                <TableCell colSpan={5} className="text-center py-8">
                                  <div className="animate-pulse space-y-3">
                                    {[1, 2, 3, 4, 5].map((i) => (
                                      <div key={i} className="h-16 bg-gray-200 rounded"></div>
                                    ))}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ) : members.length === 0 ? (
                              <TableRow>
                                <TableCell colSpan={5} className="text-center py-8">
                                  <div className="text-center text-muted-foreground">
                                    <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                                    <p>暂无成员数据</p>
                                    <p className="text-sm">请检查筛选条件或添加新成员</p>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ) : (
                              members.map((member) => (
                                <TableRow key={member.id}>
                                  <TableCell className="w-[300px] px-3">
                                    <div className="flex items-center space-x-2">
                                      <Avatar className="h-8 w-8 flex-shrink-0">
                                        <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${member.student.studentId}`} />
                                        <AvatarFallback>{member.student.name.charAt(0)}</AvatarFallback>
                                      </Avatar>
                                      <div className="min-w-0 flex-1">
                                        <div className="font-medium truncate">{member.student.name}</div>
                                        <div className="text-sm text-muted-foreground truncate">
                                          {member.student.studentId} • {member.student.email}
                                        </div>
                                      </div>
                                    </div>
                                  </TableCell>
                                  <TableCell className="w-[100px] px-3">
                                    <Badge 
                                      variant={member.role === 'MANAGER' ? 'default' : 'secondary'}
                                      className={member.role === 'MANAGER' ? 'bg-yellow-100 text-yellow-800' : ''}
                                    >
                                      {member.role === 'MANAGER' ? '社长' : 
                                       member.role === 'STAFF' ? '干事' : '会员'}
                                    </Badge>
                                  </TableCell>
                                  <TableCell className="w-[100px] px-3">
                                    <Badge 
                                      variant={member.status === 'ACTIVE' ? 'default' : 'secondary'}
                                    >
                                      {member.status === 'ACTIVE' ? '在社' : '已退出'}
                                    </Badge>
                                  </TableCell>
                                  <TableCell className="w-[120px] px-3">
                                    <div className="text-sm">
                                      {new Date(member.joinedAt).toLocaleDateString()}
                                    </div>
                                  </TableCell>
                                  <TableCell className="w-[150px] px-3">
                                    <div className="flex space-x-2">
                                      {member.role !== 'MANAGER' && (
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() => {
                                            setSelectedMember(member)
                                            setIsSetManagerDialogOpen(true)
                                          }}
                                        >
                                          <Crown className="h-4 w-4 mr-1" />
                                          设为社长
                                        </Button>
                                      )}
                                      {member.role === 'MANAGER' && (
                                        <Button
                                          size="sm"
                                          variant="destructive"
                                          onClick={() => setIsRemoveManagerDialogOpen(true)}
                                        >
                                          退位
                                        </Button>
                                      )}
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))
                            )}
                          </TableBody>
                        </Table>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">
                      共 {members.length} 条记录，第 {memberCurrentPage} / {memberTotalPages} 页
                    </div>
                    <div className="flex space-x-1">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setMemberCurrentPage(Math.max(1, memberCurrentPage - 1))}
                        disabled={memberCurrentPage === 1}
                      >
                        上一页
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setMemberCurrentPage(Math.min(memberTotalPages, memberCurrentPage + 1))}
                        disabled={memberCurrentPage === memberTotalPages}
                      >
                        下一页
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          )}
          
          <DialogFooter className="sticky bottom-0 bg-background border-t">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              取消
            </Button>
            <Button>
              保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 设置社长确认对话框 */}
      <Dialog open={isSetManagerDialogOpen} onOpenChange={setIsSetManagerDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>设置社长</DialogTitle>
            <DialogDescription>
              确定要将 {selectedMember?.name} 设置为社长吗？
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {selectedMember && (
              <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                <Avatar className="h-12 w-12 flex-shrink-0">
                  <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedMember.student.studentId}`} />
                  <AvatarFallback>{selectedMember.student.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="min-w-0 flex-1">
                  <div className="font-medium">{selectedMember.student.name}</div>
                  <div className="text-sm text-muted-foreground truncate">
                    {selectedMember.student.studentId} • {selectedMember.student.email}
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    当前角色：{selectedMember.role === 'STAFF' ? '干事' : '会员'}
                  </div>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSetManagerDialogOpen(false)}>
              取消
            </Button>
            <Button>
              确认设置
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 社长退位确认对话框 */}
      <Dialog open={isRemoveManagerDialogOpen} onOpenChange={setIsRemoveManagerDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>社长退位</DialogTitle>
            <DialogDescription>
              确定要让社长退位吗？退位后该社团将暂时没有社长。
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <div className="flex items-center space-x-2 text-yellow-800">
                <Crown className="h-5 w-5" />
                <span className="font-medium">重要提醒</span>
              </div>
              <ul className="mt-2 text-sm text-yellow-700 space-y-1">
                <li>• 社长退位后，该社团将暂时没有社长</li>
                <li>• 原社长将变为普通会员身份</li>
                <li>• 您可以稍后重新设置新的社长</li>
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRemoveManagerDialogOpen(false)}>
              取消
            </Button>
            <Button variant="destructive">
              确认退位
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}